package com.example.pingpong.network;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Detects the machine's LAN IPv4 addresses so the host can tell the second player where to connect. */
@Component
public class NetworkUtils {

    private static final List<String> VIRTUAL_NAME_HINTS =
            List.of("docker", "veth", "vmnet", "vbox", "virbr", "vethernet", "br-", "utun", "tailscale", "zt");

    private final int port;

    public NetworkUtils(@Value("${server.port:8080}") int port) {
        this.port = port;
    }

    /** Private IPv4 addresses of active, non-virtual interfaces. 192.168.x.x first, then 10.x, then 172.16/12. */
    public static List<String> detectLanIpv4Addresses() {
        List<String> home = new ArrayList<>();
        List<String> tenNet = new ArrayList<>();
        List<String> other = new ArrayList<>();
        try {
            var nics = NetworkInterface.getNetworkInterfaces();
            if (nics == null) return List.of();
            for (NetworkInterface nic : Collections.list(nics)) {
                if (!nic.isUp() || nic.isLoopback() || nic.isPointToPoint()) continue;
                String name = nic.getName().toLowerCase(Locale.ROOT);
                if (VIRTUAL_NAME_HINTS.stream().anyMatch(name::startsWith)) continue;
                for (InetAddress a : Collections.list(nic.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || !a.isSiteLocalAddress()) continue;
                    String ip = a.getHostAddress();
                    if (ip.startsWith("192.168.")) home.add(ip);
                    else if (ip.startsWith("10.")) tenNet.add(ip);
                    else other.add(ip);
                }
            }
        } catch (SocketException e) {
            return List.of();
        }
        List<String> all = new ArrayList<>(home);
        all.addAll(tenNet);
        all.addAll(other);
        return all;
    }

    public int getPort() { return port; }

    /** Connection details for the UI. Contains only the LAN address and port - nothing sensitive. */
    public Map<String, Object> connectionInfo() {
        List<String> addresses = detectLanIpv4Addresses();
        List<String> urls = addresses.stream().map(ip -> "http://" + ip + ":" + port).toList();
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("port", port);
        info.put("addresses", addresses);
        info.put("urls", urls);
        info.put("primaryUrl", urls.isEmpty() ? null : urls.get(0));
        return info;
    }
}
