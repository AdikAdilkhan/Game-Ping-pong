package com.example.pingpong.controller;

import com.example.pingpong.service.GameService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;

/**
 * Thin transport layer: parses JSON, applies a per-connection flood limit and forwards to {@link GameService}.
 * Every connection is wrapped so that sends from the game-loop thread and message threads cannot interleave.
 */
@Component
public class GameWebSocketController extends TextWebSocketHandler {

    private static final int MAX_MESSAGES_PER_SECOND = 400;

    private final GameService gameService;
    private final ObjectMapper mapper;
    private final Map<String, ConcurrentWebSocketSessionDecorator> sessions = new ConcurrentHashMap<>();
    private final Map<String, long[]> rate = new ConcurrentHashMap<>(); // id -> [windowStartMillis, count]

    public GameWebSocketController(GameService gameService, ObjectMapper mapper) {
        this.gameService = gameService;
        this.mapper = mapper;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        sessions.put(session.getId(), new ConcurrentWebSocketSessionDecorator(session, 5_000, 64 * 1024));
        rate.put(session.getId(), new long[] {System.currentTimeMillis(), 0});
    }

    @Override
    protected void handleTextMessage(WebSocketSession raw, TextMessage message) throws Exception {
        WebSocketSession session = sessions.get(raw.getId());
        if (session == null) return;

        if (!allow(raw.getId())) {
            session.close(CloseStatus.POLICY_VIOLATION.withReason("Too many messages"));
            return;
        }

        JsonNode node;
        try {
            node = mapper.readTree(message.getPayload());
        } catch (Exception e) {
            gameService.sendError(session, "BAD_MESSAGE", "Message was not valid JSON.");
            return;
        }
        if (node == null || !node.isObject()) {
            gameService.sendError(session, "BAD_MESSAGE", "Message must be a JSON object.");
            return;
        }

        if ("join".equals(node.path("type").asText())) {
            gameService.attach(session, node.path("code").asText(null), node.path("playerId").asText(null));
        } else {
            gameService.onMessage(session, node);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession raw, CloseStatus status) {
        ConcurrentWebSocketSessionDecorator session = sessions.remove(raw.getId());
        rate.remove(raw.getId());
        gameService.onClose(session != null ? session : raw);
    }

    @Override
    public void handleTransportError(WebSocketSession raw, Throwable exception) throws Exception {
        raw.close(CloseStatus.SERVER_ERROR);
    }

    /** Simple one-second window flood protection. */
    private boolean allow(String id) {
        long[] w = rate.get(id);
        if (w == null) return false;
        long now = System.currentTimeMillis();
        if (now - w[0] >= 1000) {
            w[0] = now;
            w[1] = 0;
        }
        return ++w[1] <= MAX_MESSAGES_PER_SECOND;
    }
}
