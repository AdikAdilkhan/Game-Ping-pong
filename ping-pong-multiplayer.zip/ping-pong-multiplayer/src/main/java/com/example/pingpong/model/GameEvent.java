package com.example.pingpong.model;

/** A one-off thing that happened during simulation (used for sounds and particles on clients). */
public record GameEvent(String type, double x, double y, int slot) {
    public static final String PADDLE = "paddle";
    public static final String WALL = "wall";
    public static final String SCORE = "score";
    public static final String WIN = "win";
}
