package com.example.pingpong.model;

import java.util.ArrayList;
import java.util.List;

/**
 * One match room with at most two players. All access to a room's mutable data must happen inside
 * {@code synchronized (room)}: the WebSocket threads and the game-loop thread share it that way.
 */
public class GameRoom {
    private final String code;
    private final boolean publicRoom;
    private final Player[] players = new Player[2];
    private final GameState state = new GameState();
    private final List<GameEvent> pendingEvents = new ArrayList<>();
    private long lastTickNanos = System.nanoTime();
    private long tickCounter;

    public GameRoom(String code, boolean publicRoom) {
        this.code = code;
        this.publicRoom = publicRoom;
    }

    public String getCode() { return code; }
    public boolean isPublicRoom() { return publicRoom; }
    public GameState getState() { return state; }

    /** @param slot 1 or 2 */
    public Player player(int slot) { return players[slot - 1]; }
    public void setPlayer(int slot, Player p) { players[slot - 1] = p; }
    public void removePlayer(int slot) { players[slot - 1] = null; }
    public Player[] getPlayers() { return players.clone(); }

    public Player playerById(String id) {
        if (id == null) return null;
        for (Player p : players) {
            if (p != null && p.getId().equals(id)) return p;
        }
        return null;
    }

    public Player opponentOf(Player p) { return players[p.getSlot() == 1 ? 1 : 0]; }
    public boolean isFull() { return players[0] != null && players[1] != null; }
    public boolean allConnected() { return isFull() && players[0].isConnected() && players[1].isConnected(); }

    public int connectedCount() {
        int n = 0;
        for (Player p : players) if (p != null && p.isConnected()) n++;
        return n;
    }

    public void addEvents(List<GameEvent> events) { pendingEvents.addAll(events); }

    public List<GameEvent> drainEvents() {
        List<GameEvent> copy = new ArrayList<>(pendingEvents);
        pendingEvents.clear();
        return copy;
    }

    public long getLastTickNanos() { return lastTickNanos; }
    public void setLastTickNanos(long n) { this.lastTickNanos = n; }
    public long nextTick() { return ++tickCounter; }
}
