package com.example.pingpong.network;

import java.util.List;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/** Prints the URL the second device should open as soon as the server is up. */
@Component
public class StartupBanner {

    private final NetworkUtils network;

    public StartupBanner(NetworkUtils network) {
        this.network = network;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void printBanner() {
        List<String> ips = NetworkUtils.detectLanIpv4Addresses();
        int port = network.getPort();
        StringBuilder sb = new StringBuilder("\n==============================================\n")
                .append("  NEON PONG is running\n")
                .append("  This computer : http://localhost:").append(port).append('\n');
        if (ips.isEmpty()) {
            sb.append("  Wi-Fi / LAN   : no LAN IPv4 address detected - connect to Wi-Fi and restart\n");
        } else {
            for (String ip : ips) sb.append("  Other devices : http://").append(ip).append(':').append(port).append('\n');
        }
        sb.append("==============================================");
        System.out.println(sb);
    }
}
