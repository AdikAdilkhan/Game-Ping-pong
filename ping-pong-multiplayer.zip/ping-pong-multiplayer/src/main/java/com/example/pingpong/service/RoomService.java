package com.example.pingpong.service;

import com.example.pingpong.exception.ApiException;
import com.example.pingpong.model.GameRoom;
import com.example.pingpong.model.Player;
import java.security.SecureRandom;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/** Creates, finds, joins and removes rooms. Thread-safe. */
@Service
public class RoomService {

    /** No 0/O/1/I so codes are easy to read aloud and type. */
    static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    static final Pattern CODE = Pattern.compile("^[A-HJ-NP-Z2-9]{6}$");
    static final Pattern NICKNAME = Pattern.compile("^[\\p{L}\\p{N} _.\\-]{1,16}$");
    static final int MAX_ROOMS = 500;

    private final Map<String, GameRoom> rooms = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();

    /** Result of creating or joining a room. */
    public record Joined(GameRoom room, Player player) {}

    // ------------------------------------------------------------------ create / join

    public Joined createRoom(String nickname, boolean publicRoom) {
        String nick = validateNickname(nickname);
        if (rooms.size() >= MAX_ROOMS) {
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "SERVER_BUSY", "The server is full right now. Try again later.");
        }
        for (int attempt = 0; attempt < 50; attempt++) {
            GameRoom room = new GameRoom(randomCode(), publicRoom);
            synchronized (room) { // the game loop also takes this lock, so it never sees a half-built room
                if (rooms.putIfAbsent(room.getCode(), room) == null) {
                    Player host = new Player(UUID.randomUUID().toString(), nick, 1);
                    room.setPlayer(1, host);
                    return new Joined(room, host);
                }
            }
        }
        throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "CODE_GENERATION_FAILED", "Could not create a room. Please retry.");
    }

    public Joined joinRoom(String code, String nickname) {
        String normalized = normalizeCode(code);
        String nick = validateNickname(nickname);
        GameRoom room = rooms.get(normalized);
        if (room == null) throw roomNotFound();
        synchronized (room) {
            if (rooms.get(normalized) != room) throw roomNotFound();
            return addGuest(room, nick);
        }
    }

    /** "PLAY ONLINE": joins a waiting public room if there is one, otherwise opens a new public room. */
    public Joined quickPlay(String nickname) {
        String nick = validateNickname(nickname);
        for (GameRoom room : rooms.values()) {
            if (!room.isPublicRoom()) continue;
            synchronized (room) {
                Player host = room.player(1);
                if (!room.isFull() && host != null && host.isConnected() && rooms.get(room.getCode()) == room) {
                    return addGuest(room, nick);
                }
            }
        }
        return createRoom(nick, true);
    }

    private Joined addGuest(GameRoom room, String nick) {
        if (room.isFull()) {
            throw new ApiException(HttpStatus.CONFLICT, "ROOM_FULL", "This room already has two players.");
        }
        Player guest = new Player(UUID.randomUUID().toString(), nick, 2);
        room.setPlayer(2, guest);
        return new Joined(room, guest);
    }

    // ------------------------------------------------------------------ lookup / remove

    public Optional<GameRoom> find(String code) {
        return code == null ? Optional.empty() : Optional.ofNullable(rooms.get(code));
    }

    public Collection<GameRoom> all() { return rooms.values(); }

    public void remove(String code) { rooms.remove(code); }

    public int roomCount() { return rooms.size(); }

    // ------------------------------------------------------------------ validation

    public static String normalizeCode(String code) {
        String c = code == null ? "" : code.trim().toUpperCase(Locale.ROOT);
        if (!CODE.matcher(c).matches()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "INVALID_CODE", "Room codes have 6 letters or digits, e.g. A7K92B.");
        }
        return c;
    }

    public static String validateNickname(String nickname) {
        String n = nickname == null ? "" : nickname.trim();
        if (!NICKNAME.matcher(n).matches()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "INVALID_NICKNAME",
                    "Nickname must be 1-16 characters (letters, numbers, space, . _ -).");
        }
        return n;
    }

    private static ApiException roomNotFound() {
        return new ApiException(HttpStatus.NOT_FOUND, "ROOM_NOT_FOUND", "Room not found. Check the code and try again.");
    }

    private String randomCode() {
        StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; i++) sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
        return sb.toString();
    }
}
