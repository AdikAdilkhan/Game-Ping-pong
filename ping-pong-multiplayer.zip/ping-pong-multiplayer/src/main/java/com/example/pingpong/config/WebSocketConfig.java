package com.example.pingpong.config;

import com.example.pingpong.controller.GameWebSocketController;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;

/** Registers the native WebSocket endpoint at {@code /ws}. */
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final GameWebSocketController handler;

    public WebSocketConfig(GameWebSocketController handler) {
        this.handler = handler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // LAN game: the page and the socket come from the same host, but that host's IP is not
        // known in advance, so every origin is accepted.
        registry.addHandler(handler, "/ws").setAllowedOriginPatterns("*");
    }

    /** Small message buffers: legitimate game messages are tiny, so reject anything large. */
    @Bean
    public ServletServerContainerFactoryBean webSocketContainer() {
        ServletServerContainerFactoryBean c = new ServletServerContainerFactoryBean();
        c.setMaxTextMessageBufferSize(4 * 1024);
        c.setMaxBinaryMessageBufferSize(1024);
        c.setMaxSessionIdleTimeout(5 * 60 * 1000L);
        return c;
    }
}
