package com.example.pingpong.model;

/**
 * Mutable authoritative simulation state of one match. Plain public fields on purpose: it is a
 * data holder that is only touched while holding the owning room's lock.
 */
public class GameState {
    public GameStatus status = GameStatus.LOBBY;
    public double countdown;

    public double ballX = GameConstants.WIDTH / 2;
    public double ballY = GameConstants.HEIGHT / 2;
    public double ballVx;
    public double ballVy;

    public double paddle1Y = GameConstants.HEIGHT / 2;
    public double paddle2Y = GameConstants.HEIGHT / 2;

    public int score1;
    public int score2;
    public int targetScore = 5;
    /** 0 = nobody yet, otherwise 1 or 2. */
    public int winner;
    /** Who paused: 1 or 2, or 0 when the game was paused by a connection loss. */
    public int pausedBy;

    public void resetToLobby() {
        status = GameStatus.LOBBY;
        countdown = 0;
        ballX = GameConstants.WIDTH / 2;
        ballY = GameConstants.HEIGHT / 2;
        ballVx = 0;
        ballVy = 0;
        paddle1Y = GameConstants.HEIGHT / 2;
        paddle2Y = GameConstants.HEIGHT / 2;
        score1 = 0;
        score2 = 0;
        winner = 0;
        pausedBy = 0;
    }
}
