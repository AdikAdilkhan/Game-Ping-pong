package com.example.pingpong.engine;

import static com.example.pingpong.model.GameConstants.*;

import com.example.pingpong.model.GameEvent;
import com.example.pingpong.model.GameState;
import com.example.pingpong.model.GameStatus;
import com.example.pingpong.model.PlayerInput;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Pure Ping Pong simulation: no threads and no I/O. The caller (GameService) owns locking and timing,
 * which keeps this class trivially unit-testable.
 * Coordinates: x to the right, y DOWN, origin top-left of an 800x500 arena.
 */
public class GameEngine {
    /** The ball is advanced in sub-steps this small so a fast ball can never tunnel through a paddle. */
    private static final double MAX_SUBSTEP = 1.0 / 120.0;

    private final Random random;

    public GameEngine() { this(new Random()); }
    public GameEngine(Random random) { this.random = random; }

    // ------------------------------------------------------------ lifecycle

    /** Resets scores and positions and starts the 3-second countdown. Keeps the target score. */
    public void startMatch(GameState s) {
        s.score1 = 0;
        s.score2 = 0;
        s.winner = 0;
        s.pausedBy = 0;
        s.paddle1Y = HEIGHT / 2;
        s.paddle2Y = HEIGHT / 2;
        resetBall(s, random.nextBoolean() ? 1 : -1);
        s.status = GameStatus.COUNTDOWN;
        s.countdown = START_COUNTDOWN;
    }

    public void pause(GameState s, int by) {
        if (s.status == GameStatus.PLAYING || s.status == GameStatus.COUNTDOWN) {
            s.status = GameStatus.PAUSED;
            s.pausedBy = by;
        }
    }

    /** Leaves PAUSED through a fresh countdown so nobody is surprised by a moving ball. */
    public void resume(GameState s) {
        if (s.status == GameStatus.PAUSED) {
            s.status = GameStatus.COUNTDOWN;
            s.countdown = START_COUNTDOWN;
            s.pausedBy = 0;
        }
    }

    // ------------------------------------------------------------ simulation

    /** Advances the match by {@code dt} seconds and returns what happened (bounces, points...). */
    public List<GameEvent> update(GameState s, PlayerInput in1, PlayerInput in2, double dt) {
        List<GameEvent> events = new ArrayList<>(2);
        if (!(dt > 0)) return events;

        if (s.status == GameStatus.COUNTDOWN) {
            movePaddles(s, in1, in2, dt);
            s.countdown -= dt;
            if (s.countdown <= 0) {
                s.countdown = 0;
                s.status = GameStatus.PLAYING;
            }
        } else if (s.status == GameStatus.PLAYING) {
            movePaddles(s, in1, in2, dt);
            int steps = (int) Math.ceil(dt / MAX_SUBSTEP);
            double h = dt / steps;
            for (int i = 0; i < steps && s.status == GameStatus.PLAYING; i++) {
                stepBall(s, h, events);
            }
        }
        return events;
    }

    private void movePaddles(GameState s, PlayerInput in1, PlayerInput in2, double dt) {
        s.paddle1Y = movePaddle(s.paddle1Y, in1, dt);
        s.paddle2Y = movePaddle(s.paddle2Y, in2, dt);
    }

    static double movePaddle(double y, PlayerInput in, double dt) {
        if (in.getDir() != 0) {
            y += in.getDir() * PADDLE_SPEED * dt;
        } else if (in.getTargetY() != null) {
            double max = TARGET_FOLLOW_SPEED * dt;
            y += Math.max(-max, Math.min(max, in.getTargetY() - y));
        }
        double half = PADDLE_HEIGHT / 2;
        return Math.max(half, Math.min(HEIGHT - half, y));
    }

    private void stepBall(GameState s, double dt, List<GameEvent> events) {
        s.ballX += s.ballVx * dt;
        s.ballY += s.ballVy * dt;

        // Walls
        if (s.ballY - BALL_RADIUS < 0) {
            s.ballY = BALL_RADIUS;
            s.ballVy = Math.abs(s.ballVy);
            events.add(new GameEvent(GameEvent.WALL, s.ballX, 0, 0));
        } else if (s.ballY + BALL_RADIUS > HEIGHT) {
            s.ballY = HEIGHT - BALL_RADIUS;
            s.ballVy = -Math.abs(s.ballVy);
            events.add(new GameEvent(GameEvent.WALL, s.ballX, HEIGHT, 0));
        }

        // Left paddle (player 1): the ball must be travelling left and overlap the paddle's x-range.
        double leftFace = PADDLE_MARGIN + PADDLE_WIDTH;
        if (s.ballVx < 0 && s.ballX - BALL_RADIUS <= leftFace && s.ballX + BALL_RADIUS >= PADDLE_MARGIN
                && Math.abs(s.ballY - s.paddle1Y) <= PADDLE_HEIGHT / 2 + BALL_RADIUS * 0.6) {
            bounce(s, 1, s.paddle1Y, events);
        }

        // Right paddle (player 2)
        double rightFace = WIDTH - PADDLE_MARGIN - PADDLE_WIDTH;
        if (s.ballVx > 0 && s.ballX + BALL_RADIUS >= rightFace && s.ballX - BALL_RADIUS <= WIDTH - PADDLE_MARGIN
                && Math.abs(s.ballY - s.paddle2Y) <= PADDLE_HEIGHT / 2 + BALL_RADIUS * 0.6) {
            bounce(s, 2, s.paddle2Y, events);
        }

        // Scoring: the ball has completely left the arena behind a paddle.
        if (s.ballX + BALL_RADIUS < 0) {
            point(s, 2, events);
        } else if (s.ballX - BALL_RADIUS > WIDTH) {
            point(s, 1, events);
        }
    }

    private void bounce(GameState s, int slot, double paddleY, List<GameEvent> events) {
        double rel = Math.max(-1, Math.min(1, (s.ballY - paddleY) / (PADDLE_HEIGHT / 2 + BALL_RADIUS)));
        double angle = rel * MAX_BOUNCE_ANGLE + (random.nextDouble() * 2 - 1) * ANGLE_JITTER;
        double speed = Math.min(Math.hypot(s.ballVx, s.ballVy) * SPEED_GAIN, MAX_BALL_SPEED);
        double dir = slot == 1 ? 1 : -1;
        s.ballVx = dir * speed * Math.cos(angle);
        s.ballVy = speed * Math.sin(angle);
        s.ballX = slot == 1
                ? PADDLE_MARGIN + PADDLE_WIDTH + BALL_RADIUS
                : WIDTH - PADDLE_MARGIN - PADDLE_WIDTH - BALL_RADIUS;
        events.add(new GameEvent(GameEvent.PADDLE, s.ballX, s.ballY, slot));
    }

    private void point(GameState s, int scorer, List<GameEvent> events) {
        if (scorer == 1) s.score1++; else s.score2++;
        events.add(new GameEvent(GameEvent.SCORE, Math.max(0, Math.min(WIDTH, s.ballX)), s.ballY, scorer));

        if ((scorer == 1 ? s.score1 : s.score2) >= s.targetScore) {
            s.status = GameStatus.GAME_OVER;
            s.winner = scorer;
            s.ballVx = 0;
            s.ballVy = 0;
            s.ballX = WIDTH / 2;
            s.ballY = HEIGHT / 2;
            events.add(new GameEvent(GameEvent.WIN, WIDTH / 2, HEIGHT / 2, scorer));
        } else {
            // Serve towards the player who just conceded.
            resetBall(s, scorer == 1 ? 1 : -1);
            s.status = GameStatus.COUNTDOWN;
            s.countdown = SERVE_DELAY;
        }
    }

    private void resetBall(GameState s, int dir) {
        s.ballX = WIDTH / 2;
        s.ballY = HEIGHT / 2;
        double angle = (random.nextDouble() * 2 - 1) * MAX_SERVE_ANGLE;
        s.ballVx = dir * INITIAL_BALL_SPEED * Math.cos(angle);
        s.ballVy = INITIAL_BALL_SPEED * Math.sin(angle);
    }
}
