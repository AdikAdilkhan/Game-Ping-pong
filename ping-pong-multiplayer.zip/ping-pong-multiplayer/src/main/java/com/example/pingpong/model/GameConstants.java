package com.example.pingpong.model;

/** Logical arena geometry and physics tuning. The client scales this 800x500 space to the screen. */
public final class GameConstants {
    private GameConstants() {}

    public static final double WIDTH = 800;
    public static final double HEIGHT = 500;
    public static final double PADDLE_WIDTH = 14;
    public static final double PADDLE_HEIGHT = 90;
    public static final double PADDLE_MARGIN = 24;
    public static final double BALL_RADIUS = 8;

    /** Keyboard paddle speed (units / second). */
    public static final double PADDLE_SPEED = 520;
    /** Max speed when a paddle chases a mouse/touch target. Prevents teleporting. */
    public static final double TARGET_FOLLOW_SPEED = 900;

    public static final double INITIAL_BALL_SPEED = 380;
    public static final double MAX_BALL_SPEED = 900;
    public static final double SPEED_GAIN = 1.05;

    public static final double MAX_BOUNCE_ANGLE = Math.toRadians(55);
    public static final double ANGLE_JITTER = Math.toRadians(3);
    public static final double MAX_SERVE_ANGLE = Math.toRadians(25);

    public static final double START_COUNTDOWN = 3.0;
    public static final double SERVE_DELAY = 1.0;
}
