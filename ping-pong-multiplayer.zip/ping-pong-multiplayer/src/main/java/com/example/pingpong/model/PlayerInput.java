package com.example.pingpong.model;

/**
 * The latest validated control intent of one player: either a direction (-1 up, 0 none, 1 down)
 * or an absolute target Y (mouse / touch). Accessed only while holding the room lock.
 */
public class PlayerInput {
    private int dir;
    private Double targetY;

    public void setDirection(int direction) {
        if (direction < -1 || direction > 1) {
            throw new IllegalArgumentException("direction must be -1, 0 or 1");
        }
        this.dir = direction;
        this.targetY = null;
    }

    public void setTarget(double y) {
        if (!Double.isFinite(y)) {
            throw new IllegalArgumentException("target must be a finite number");
        }
        this.targetY = Math.max(0, Math.min(GameConstants.HEIGHT, y));
        this.dir = 0;
    }

    public void clear() {
        this.dir = 0;
        this.targetY = null;
    }

    public int getDir() { return dir; }
    public Double getTargetY() { return targetY; }
}
