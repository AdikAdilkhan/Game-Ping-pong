package com.example.pingpong.controller;

import com.example.pingpong.model.GameRoom;
import com.example.pingpong.network.NetworkUtils;
import com.example.pingpong.service.RoomService;
import com.example.pingpong.service.RoomService.Joined;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** REST API for room management. Gameplay itself runs over the WebSocket at /ws. */
@RestController
@RequestMapping("/api")
public class RoomController {

    public record NicknameRequest(String nickname) {}

    private final RoomService rooms;
    private final NetworkUtils network;

    public RoomController(RoomService rooms, NetworkUtils network) {
        this.rooms = rooms;
        this.network = network;
    }

    @PostMapping("/rooms")
    public ResponseEntity<Map<String, Object>> create(@RequestBody NicknameRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(toResponse(rooms.createRoom(req.nickname(), false)));
    }

    @PostMapping("/rooms/quick")
    public Map<String, Object> quickPlay(@RequestBody NicknameRequest req) {
        return toResponse(rooms.quickPlay(req.nickname()));
    }

    @PostMapping("/rooms/{code}/join")
    public Map<String, Object> join(@PathVariable String code, @RequestBody NicknameRequest req) {
        return toResponse(rooms.joinRoom(code, req.nickname()));
    }

    /** Lets the join screen check a code before asking for anything else. Reveals no player data. */
    @GetMapping("/rooms/{code}")
    public Map<String, Object> info(@PathVariable String code) {
        String normalized = RoomService.normalizeCode(code);
        Map<String, Object> out = new LinkedHashMap<>();
        var room = rooms.find(normalized);
        out.put("exists", room.isPresent());
        out.put("full", room.map(r -> { synchronized (r) { return r.isFull(); } }).orElse(false));
        return out;
    }

    @GetMapping("/network")
    public Map<String, Object> network() {
        return network.connectionInfo();
    }

    private Map<String, Object> toResponse(Joined joined) {
        GameRoom room = joined.room();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("code", room.getCode());
        out.put("playerId", joined.player().getId());   // secret token: only ever returned to its owner
        out.put("slot", joined.player().getSlot());
        out.put("host", joined.player().isHost());
        out.put("network", network.connectionInfo());
        return out;
    }
}
