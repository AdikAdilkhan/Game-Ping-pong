package com.example.pingpong.service;

import com.example.pingpong.engine.GameEngine;
import com.example.pingpong.model.GameEvent;
import com.example.pingpong.model.GameRoom;
import com.example.pingpong.model.GameState;
import com.example.pingpong.model.GameStatus;
import com.example.pingpong.model.Player;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

/**
 * Match management: binds WebSocket sessions to players, validates and applies their actions, runs the
 * scheduled server-authoritative game loop and broadcasts state.
 *
 * <p>Concurrency model: every room is guarded by {@code synchronized (room)}. WebSocket threads and the
 * single game-loop thread therefore never mutate the same room at the same time.
 */
@Service
public class GameService {

    private static final Logger log = LoggerFactory.getLogger(GameService.class);
    private static final Set<Integer> TARGET_SCORES = Set.of(5, 7, 10);
    /** Mouse/touch target updates faster than this are dropped (~120/s max). */
    private static final long MIN_TARGET_INTERVAL_NANOS = 8_000_000L;

    private record Binding(String code, String playerId) {}

    private final RoomService roomService;
    private final ObjectMapper mapper;
    private final GameEngine engine = new GameEngine();
    private final Map<String, Binding> bindings = new ConcurrentHashMap<>();
    private final int tickRate;
    private final int broadcastDivisor;
    private final long graceMillis;
    private ScheduledExecutorService scheduler;

    public GameService(RoomService roomService,
                       ObjectMapper mapper,
                       @Value("${pingpong.tick-rate:60}") int tickRate,
                       @Value("${pingpong.broadcast-divisor:2}") int broadcastDivisor,
                       @Value("${pingpong.disconnect-grace-seconds:30}") long graceSeconds) {
        this.roomService = roomService;
        this.mapper = mapper;
        this.tickRate = Math.max(10, tickRate);
        this.broadcastDivisor = Math.max(1, broadcastDivisor);
        this.graceMillis = graceSeconds * 1000L;
    }

    // ================================================================== lifecycle

    @PostConstruct
    void start() {
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "game-loop");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleAtFixedRate(this::tick, 200_000_000L, 1_000_000_000L / tickRate, TimeUnit.NANOSECONDS);
    }

    @PreDestroy
    void stop() {
        if (scheduler != null) scheduler.shutdownNow();
    }

    // ================================================================== session binding

    /** Binds a WebSocket to an existing player (first connection or reconnection). */
    public void attach(WebSocketSession session, String code, String playerId) {
        GameRoom room = code == null ? null : roomService.find(code.trim().toUpperCase(Locale.ROOT)).orElse(null);
        if (room == null) {
            sendError(session, "ROOM_NOT_FOUND", "Room not found. It may have been closed.");
            closeQuietly(session);
            return;
        }
        synchronized (room) {
            Player player = room.playerById(playerId);
            if (player == null) {
                sendError(session, "INVALID_PLAYER", "You are not part of this room.");
                closeQuietly(session);
                return;
            }
            // Duplicate session: the newest connection wins, the old one is told and closed.
            WebSocketSession old = player.getSession();
            if (old != null && !old.getId().equals(session.getId())) {
                bindings.remove(old.getId());
                sendError(old, "REPLACED", "This player joined from another tab or device.");
                closeQuietly(old);
            }
            boolean wasDown = !player.isConnected();
            player.setSession(session);
            player.setConnected(true);
            player.setDisconnectedAt(0);
            bindings.put(session.getId(), new Binding(room.getCode(), player.getId()));

            send(session, msg("type", "welcome", "code", room.getCode(), "slot", player.getSlot(), "host", player.isHost()));

            GameState s = room.getState();
            Player other = room.opponentOf(player);
            if (wasDown && other != null && other.isConnected()) {
                notice(other, "OPPONENT_RECONNECTED", player.getNickname() + " is back.");
            }
            if (s.status == GameStatus.PAUSED && s.pausedBy == 0 && room.allConnected()) {
                engine.resume(s); // paused only because somebody dropped; both are back now
            }
            broadcastRoom(room);
            broadcastState(room);
        }
    }

    /** Called when a socket closes. Marks the player disconnected and pauses a running match. */
    public void onClose(WebSocketSession session) {
        Binding b = bindings.remove(session.getId());
        if (b == null) return; // never joined, or already replaced by a newer connection
        GameRoom room = roomService.find(b.code()).orElse(null);
        if (room == null) return;
        synchronized (room) {
            Player p = room.playerById(b.playerId());
            if (p == null || p.getSession() == null || !p.getSession().getId().equals(session.getId())) return;
            p.setSession(null);
            p.setConnected(false);
            p.setDisconnectedAt(System.currentTimeMillis());
            p.getInput().clear();
            GameState s = room.getState();
            if (s.status == GameStatus.COUNTDOWN || s.status == GameStatus.PLAYING) {
                engine.pause(s, 0);
            }
            Player other = room.opponentOf(p);
            if (other != null) {
                notice(other, "OPPONENT_DISCONNECTED",
                        p.getNickname() + " lost connection. Waiting up to " + graceMillis / 1000 + " seconds for them to return...");
            }
            broadcastRoom(room);
            broadcastState(room);
        }
    }

    // ================================================================== incoming messages

    public void onMessage(WebSocketSession session, JsonNode msg) {
        Binding b = bindings.get(session.getId());
        if (b == null) {
            sendError(session, "NOT_JOINED", "Join a room first.");
            return;
        }
        GameRoom room = roomService.find(b.code()).orElse(null);
        if (room == null) {
            sendError(session, "ROOM_NOT_FOUND", "This room no longer exists.");
            return;
        }
        String type = msg.path("type").asText("");
        synchronized (room) {
            Player p = room.playerById(b.playerId());
            if (p == null || p.getSession() == null || !p.getSession().getId().equals(session.getId())) {
                sendError(session, "INVALID_PLAYER", "You are not part of this room.");
                return;
            }
            switch (type) {
                case "input" -> handleInput(p, msg);
                case "ready" -> handleReady(room, p, msg);
                case "settings" -> handleSettings(room, p, msg);
                case "start" -> handleStart(room, p);
                case "pause" -> handlePause(room, p);
                case "resume" -> handleResume(room, p);
                case "restart" -> handleRestart(room, p);
                case "rematch" -> handleRematch(room, p);
                case "leave" -> removePlayer(room, p);
                case "ping" -> send(session, msg("type", "pong", "t", msg.path("t").asLong(0)));
                default -> sendError(session, "UNKNOWN_ACTION", "Unknown action.");
            }
        }
    }

    private void handleInput(Player p, JsonNode msg) {
        // A player can only ever steer the paddle of their own slot: the target is derived from the
        // authenticated socket, never from the message.
        try {
            JsonNode dir = msg.get("dir");
            JsonNode y = msg.get("y");
            if (dir != null && dir.isInt()) {
                p.getInput().setDirection(dir.asInt());
            } else if (y != null && y.isNumber()) {
                long now = System.nanoTime();
                if (now - p.getLastTargetInputNanos() < MIN_TARGET_INTERVAL_NANOS) return; // flood control
                p.setLastTargetInputNanos(now);
                p.getInput().setTarget(y.asDouble());
            } else {
                sendError(p.getSession(), "INVALID_INPUT", "Input needs dir (-1, 0, 1) or y.");
            }
        } catch (IllegalArgumentException e) {
            sendError(p.getSession(), "INVALID_INPUT", "Invalid input value.");
        }
    }

    private void handleReady(GameRoom room, Player p, JsonNode msg) {
        if (room.getState().status != GameStatus.LOBBY) return;
        if (!p.isHost()) p.setReady(msg.path("ready").asBoolean(true));
        broadcastRoom(room);
    }

    private void handleSettings(GameRoom room, Player p, JsonNode msg) {
        if (!requireHost(p)) return;
        int target = msg.path("targetScore").asInt(0);
        if (!TARGET_SCORES.contains(target)) {
            sendError(p.getSession(), "INVALID_SETTING", "Target score must be 5, 7 or 10.");
            return;
        }
        if (room.getState().status != GameStatus.LOBBY) {
            sendError(p.getSession(), "INVALID_STATE", "The target score can only be changed in the lobby.");
            return;
        }
        room.getState().targetScore = target;
        broadcastRoom(room);
    }

    private void handleStart(GameRoom room, Player p) {
        if (!requireHost(p)) return;
        Player guest = room.player(2);
        if (room.getState().status != GameStatus.LOBBY || guest == null || !room.allConnected() || !guest.isReady()) {
            sendError(p.getSession(), "NOT_READY", "Both players must be connected and ready.");
            return;
        }
        beginMatch(room);
    }

    private void handlePause(GameRoom room, Player p) {
        GameState s = room.getState();
        if (s.status == GameStatus.PLAYING) {
            engine.pause(s, p.getSlot());
            broadcastRoom(room);
            broadcastState(room);
        }
    }

    private void handleResume(GameRoom room, Player p) {
        GameState s = room.getState();
        if (s.status != GameStatus.PAUSED) return;
        if (!room.allConnected()) {
            sendError(p.getSession(), "OPPONENT_OFFLINE", "Waiting for your opponent to reconnect.");
            return;
        }
        engine.resume(s);
        broadcastRoom(room);
        broadcastState(room);
    }

    private void handleRestart(GameRoom room, Player p) {
        if (!requireHost(p)) return;
        GameStatus st = room.getState().status;
        if ((st == GameStatus.PLAYING || st == GameStatus.PAUSED || st == GameStatus.COUNTDOWN) && room.allConnected()) {
            beginMatch(room);
        }
    }

    private void handleRematch(GameRoom room, Player p) {
        if (room.getState().status != GameStatus.GAME_OVER) return;
        p.setRematch(true);
        if (room.isFull() && room.player(1).isRematch() && room.player(2).isRematch() && room.allConnected()) {
            beginMatch(room);
        } else {
            broadcastRoom(room);
        }
    }

    private boolean requireHost(Player p) {
        if (!p.isHost()) {
            sendError(p.getSession(), "NOT_HOST", "Only the host can do that.");
            return false;
        }
        return true;
    }

    private void beginMatch(GameRoom room) {
        for (Player pl : room.getPlayers()) {
            if (pl != null) {
                pl.setRematch(false);
                pl.getInput().clear();
            }
        }
        engine.startMatch(room.getState());
        room.drainEvents();
        broadcastRoom(room);
        broadcastState(room);
    }

    // ================================================================== leaving / cleanup

    /** Explicit leave or grace-period expiry. A leaving host closes the room; a leaving guest reopens the lobby. */
    void removePlayer(GameRoom room, Player leaving) {
        if (leaving.isHost()) {
            closeRoom(room, "The host left the room.");
            return;
        }
        detach(leaving);
        room.removePlayer(2);
        room.getState().resetToLobby();
        Player host = room.player(1);
        if (host != null) {
            host.setReady(true);
            host.setRematch(false);
            host.getInput().clear();
            notice(host, "OPPONENT_LEFT", leaving.getNickname() + " left the room.");
        }
        broadcastRoom(room);
        broadcastState(room);
    }

    private void closeRoom(GameRoom room, String reason) {
        for (Player p : room.getPlayers()) {
            if (p == null) continue;
            if (p.getSession() != null) send(p.getSession(), msg("type", "closed", "message", reason));
            detach(p);
        }
        roomService.remove(room.getCode());
    }

    private void detach(Player p) {
        WebSocketSession s = p.getSession();
        if (s != null) {
            bindings.remove(s.getId());
            closeQuietly(s);
        }
        p.setSession(null);
        p.setConnected(false);
    }

    // ================================================================== game loop

    /** Scheduled entry point. Must never throw, otherwise the scheduler would silently stop. */
    public void tick() {
        try {
            tick(System.nanoTime(), System.currentTimeMillis());
        } catch (Throwable t) {
            log.error("Game loop error", t);
        }
    }

    /** Package-visible so tests can drive time explicitly. */
    void tick(long nowNanos, long nowMillis) {
        for (GameRoom room : roomService.all()) {
            try {
                synchronized (room) {
                    tickRoom(room, nowNanos, nowMillis);
                }
            } catch (RuntimeException e) {
                log.warn("Error ticking room {}", room.getCode(), e);
            }
        }
    }

    private void tickRoom(GameRoom room, long nowNanos, long nowMillis) {
        double dt = Math.max(0, Math.min(0.05, (nowNanos - room.getLastTickNanos()) / 1e9));
        room.setLastTickNanos(nowNanos);

        Player p1 = room.player(1);
        Player p2 = room.player(2);
        if (p1 == null) return;

        // Anyone gone longer than the grace period is removed (never-attached players count as gone).
        for (Player p : room.getPlayers()) {
            if (p != null && !p.isConnected() && nowMillis - p.getDisconnectedAt() > graceMillis) {
                removePlayer(room, p);
                return;
            }
        }

        GameState s = room.getState();
        if (p2 == null || (s.status != GameStatus.COUNTDOWN && s.status != GameStatus.PLAYING)) return;

        GameStatus before = s.status;
        List<GameEvent> events = engine.update(s, p1.getInput(), p2.getInput(), dt);
        room.addEvents(events);

        if (s.status == GameStatus.GAME_OVER) {
            broadcastRoom(room);
            broadcastState(room);
        } else if (before != s.status || room.nextTick() % broadcastDivisor == 0) {
            broadcastState(room);
        }
    }

    // ================================================================== outgoing messages

    private void broadcastRoom(GameRoom room) {
        GameState s = room.getState();
        List<Object> players = new ArrayList<>();
        for (int slot = 1; slot <= 2; slot++) {
            Player p = room.player(slot);
            players.add(p == null ? null : msg(
                    "slot", slot, "nickname", p.getNickname(), "connected", p.isConnected(),
                    "ready", p.isReady(), "rematch", p.isRematch()));
        }
        Map<String, Object> m = msg("type", "room", "code", room.getCode(), "status", s.status.name(),
                "targetScore", s.targetScore, "players", players, "pausedBy", s.pausedBy,
                "winner", s.winner, "score", List.of(s.score1, s.score2));
        broadcast(room, m);
    }

    private void broadcastState(GameRoom room) {
        GameState s = room.getState();
        Map<String, Object> m = msg("type", "state", "st", s.status.name(), "cd", round(s.countdown, 100),
                "b", List.of(round(s.ballX, 10), round(s.ballY, 10), round(s.ballVx, 10), round(s.ballVy, 10)),
                "p", List.of(round(s.paddle1Y, 10), round(s.paddle2Y, 10)),
                "sc", List.of(s.score1, s.score2), "w", s.winner, "pb", s.pausedBy);
        List<GameEvent> events = room.drainEvents();
        if (!events.isEmpty()) {
            List<Object> ev = new ArrayList<>();
            for (GameEvent e : events) ev.add(List.of(e.type(), round(e.x(), 10), round(e.y(), 10), e.slot()));
            m.put("ev", ev);
        }
        broadcast(room, m);
    }

    private void broadcast(GameRoom room, Map<String, Object> payload) {
        String json = toJson(payload);
        if (json == null) return;
        for (Player p : room.getPlayers()) {
            if (p != null && p.isConnected() && p.getSession() != null) sendRaw(p.getSession(), json);
        }
    }

    private void notice(Player to, String code, String message) {
        if (to != null && to.isConnected() && to.getSession() != null) {
            send(to.getSession(), msg("type", "notice", "code", code, "message", message));
        }
    }

    public void sendError(WebSocketSession session, String code, String message) {
        if (session != null) send(session, msg("type", "error", "code", code, "message", message));
    }

    private void send(WebSocketSession session, Object payload) {
        String json = toJson(payload);
        if (json != null) sendRaw(session, json);
    }

    private void sendRaw(WebSocketSession session, String json) {
        try {
            if (session.isOpen()) session.sendMessage(new TextMessage(json));
        } catch (IOException | RuntimeException e) {
            log.debug("Send failed for session {}: {}", session.getId(), e.toString());
        }
    }

    private String toJson(Object payload) {
        try {
            return mapper.writeValueAsString(payload);
        } catch (IOException e) {
            log.warn("Could not serialise message", e);
            return null;
        }
    }

    private void closeQuietly(WebSocketSession session) {
        try {
            session.close(CloseStatus.NORMAL);
        } catch (IOException | RuntimeException ignored) {
            // already closed
        }
    }

    /** Builds an ordered JSON object from key/value pairs. */
    private static Map<String, Object> msg(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
        return m;
    }

    private static double round(double v, double factor) {
        return Math.round(v * factor) / factor;
    }
}
