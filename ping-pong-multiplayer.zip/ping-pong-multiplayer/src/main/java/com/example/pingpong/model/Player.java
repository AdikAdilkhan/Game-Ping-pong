package com.example.pingpong.model;

import org.springframework.web.socket.WebSocketSession;

/** A participant. The secret {@code id} is the player's token; it is only ever sent to that player. */
public class Player {
    private final String id;
    private final String nickname;
    private final int slot;
    private final PlayerInput input = new PlayerInput();

    private WebSocketSession session;
    private boolean connected;
    private boolean ready;
    private boolean rematch;
    private long disconnectedAt = System.currentTimeMillis();
    private long lastTargetInputNanos;

    public Player(String id, String nickname, int slot) {
        this.id = id;
        this.nickname = nickname;
        this.slot = slot;
        this.ready = slot == 1; // the host is always ready
    }

    public String getId() { return id; }
    public String getNickname() { return nickname; }
    public int getSlot() { return slot; }
    public boolean isHost() { return slot == 1; }
    public PlayerInput getInput() { return input; }

    public WebSocketSession getSession() { return session; }
    public void setSession(WebSocketSession session) { this.session = session; }
    public boolean isConnected() { return connected; }
    public void setConnected(boolean connected) { this.connected = connected; }
    public boolean isReady() { return ready; }
    public void setReady(boolean ready) { this.ready = ready; }
    public boolean isRematch() { return rematch; }
    public void setRematch(boolean rematch) { this.rematch = rematch; }
    public long getDisconnectedAt() { return disconnectedAt; }
    public void setDisconnectedAt(long disconnectedAt) { this.disconnectedAt = disconnectedAt; }
    public long getLastTargetInputNanos() { return lastTargetInputNanos; }
    public void setLastTargetInputNanos(long n) { this.lastTargetInputNanos = n; }
}
