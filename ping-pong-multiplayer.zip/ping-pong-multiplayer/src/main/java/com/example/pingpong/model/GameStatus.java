package com.example.pingpong.model;

public enum GameStatus { LOBBY, COUNTDOWN, PLAYING, PAUSED, GAME_OVER }
