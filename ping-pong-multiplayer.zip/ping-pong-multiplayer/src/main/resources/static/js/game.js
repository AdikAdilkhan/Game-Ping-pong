'use strict';
/* Canvas renderer. It NEVER simulates physics: it only draws the latest authoritative server state,
   smoothing it with extrapolation (ball velocity) and exponential easing (paddles). */

const Game = (() => {
  const W = 800, H = 500, PW = 14, PH = 90, M = 24, BR = 8;
  const COL = ['#00f0ff', '#b14dff'];
  const $ = (s) => document.querySelector(s);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  let canvas, ctx, box, running = false, raf = 0, lastTs = 0;
  let room = null, mySlot = 1;
  let srv = { st: 'LOBBY', cd: 0, b: [W / 2, H / 2, 0, 0], p: [H / 2, H / 2], sc: [0, 0], w: 0, pb: 0, at: 0 };
  const view = { bx: W / 2, by: H / 2, p1: H / 2, p2: H / 2 };
  const trail = [];
  let flash = 0, flashSlot = 1, prevCdInt = 0;
  const pulse = [0, 0];

  function init() {
    canvas = $('#arena');
    ctx = canvas.getContext('2d');
    box = $('#arena-box');
    if (window.ResizeObserver) new ResizeObserver(resize).observe(box);
    window.addEventListener('resize', resize);
    window.addEventListener('orientationchange', () => setTimeout(resize, 250));
  }

  /** Fits the 800x500 arena into the available space; physics units never change. */
  function resize() {
    if (!box) return;
    const bw = box.clientWidth, bh = box.clientHeight;
    if (!bw || !bh) return;
    const scale = Math.min(bw / W, bh / H);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = Math.floor(W * scale), ch = Math.floor(H * scale);
    canvas.style.width = cw + 'px';
    canvas.style.height = ch + 'px';
    canvas.width = Math.floor(cw * dpr);
    canvas.height = Math.floor(ch * dpr);
  }

  function arenaY(clientY) {
    const r = canvas.getBoundingClientRect();
    return clamp((clientY - r.top) / r.height, 0, 1) * H;
  }

  // ------------------------------------------------------------------ network input
  function setRoom(r) {
    room = r;
    for (let i = 0; i < 2; i++) {
      const p = r.players[i];
      $('#hud-name' + (i + 1)).textContent = p ? p.nickname : '...';
      $('#dot' + (i + 1)).className = 'dot ' + (p && p.connected ? 'on' : 'off');
    }
    $('#hud-target').textContent = 'First to ' + r.targetScore;
    $('#hud-score1').textContent = r.score[0];
    $('#hud-score2').textContent = r.score[1];
    updateOverlay();
  }

  function applyState(m) {
    const prev = srv;
    srv = { st: m.st, cd: m.cd, b: m.b, p: m.p, sc: m.sc, w: m.w, pb: m.pb, at: performance.now() };
    $('#hud-score1').textContent = m.sc[0];
    $('#hud-score2').textContent = m.sc[1];

    if (m.ev) {
      const won = m.ev.some(e => e[0] === 'win');
      m.ev.forEach(e => handleEvent(e[0], e[1], e[2], e[3], won));
    }
    if (m.st === 'COUNTDOWN') {
      const n = Math.ceil(m.cd);
      if (n !== prevCdInt && n > 0) Sound.count();
      prevCdInt = n;
    } else {
      if (prev.st === 'COUNTDOWN' && m.st === 'PLAYING') Sound.go();
      prevCdInt = 0;
    }
    if (m.st !== 'PLAYING') { trail.length = 0; }
    if (prev.st !== m.st) updateOverlay();
  }

  function handleEvent(type, x, y, slot, matchWon) {
    if (type === 'paddle') {
      Particles.burst(x, y, COL[slot - 1], 18, 240, 0.5);
      pulse[slot - 1] = 1;
      Sound.paddle();
    } else if (type === 'wall') {
      Particles.burst(x, y, '#ffffff', 6, 130, 0.3);
      Sound.wall();
    } else if (type === 'score') {
      Particles.burst(x, y, COL[slot - 1], 40, 340, 0.9);
      flash = 1; flashSlot = slot;
      if (!matchWon) Sound.score();
    } else if (type === 'win') {
      Sound.win();
    }
  }

  function updateOverlay() {
    const ov = $('#overlay');
    if (srv.st !== 'PAUSED' || !room) { ov.classList.add('hidden'); return; }
    const resume = $('#btn-resume');
    if (srv.pb === 0) {
      $('#ov-title').textContent = 'Opponent disconnected';
      const opp = room.players[mySlot === 1 ? 1 : 0];
      $('#ov-text').textContent = (opp ? opp.nickname : 'Your opponent') + ' lost connection. Waiting for them to come back...';
      resume.classList.add('hidden');
    } else {
      const by = room.players[srv.pb - 1];
      $('#ov-title').textContent = 'Paused';
      $('#ov-text').textContent = (by ? by.nickname : 'A player') + (srv.pb === mySlot ? ' (you)' : '') + ' paused the game.';
      resume.classList.remove('hidden');
    }
    ov.classList.remove('hidden');
  }

  // ------------------------------------------------------------------ simulation smoothing
  function update(dt) {
    const age = srv.st === 'PLAYING' ? Math.min(0.12, (performance.now() - srv.at) / 1000) : 0;
    const tx = srv.b[0] + srv.b[2] * age;
    const ty = clamp(srv.b[1] + srv.b[3] * age, BR, H - BR);
    if (srv.st !== 'PLAYING' || Math.hypot(tx - view.bx, ty - view.by) > 120) {
      view.bx = tx; view.by = ty; // resets, serves and big corrections snap
    } else {
      const k = 1 - Math.exp(-dt * 28);
      view.bx += (tx - view.bx) * k;
      view.by += (ty - view.by) * k;
    }
    const kp = 1 - Math.exp(-dt * 32);
    view.p1 += (srv.p[0] - view.p1) * kp;
    view.p2 += (srv.p[1] - view.p2) * kp;

    if (srv.st === 'PLAYING') { trail.unshift({ x: view.bx, y: view.by }); if (trail.length > 14) trail.pop(); }
    Particles.update(dt);
    flash = Math.max(0, flash - dt * 2.4);
    pulse[0] = Math.max(0, pulse[0] - dt * 4);
    pulse[1] = Math.max(0, pulse[1] - dt * 4);
  }

  // ------------------------------------------------------------------ drawing
  function rr(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function paddle(x, cy, color, glow, mine) {
    ctx.save();
    ctx.shadowColor = color;
    ctx.shadowBlur = 16 + glow * 26;
    const g = ctx.createLinearGradient(x, 0, x + PW, 0);
    g.addColorStop(0, color); g.addColorStop(1, '#ffffff');
    ctx.fillStyle = g;
    rr(x, cy - PH / 2, PW, PH, 7);
    ctx.fill();
    ctx.restore();
    if (mine) {
      ctx.fillStyle = color;
      ctx.font = '700 11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('YOU', x + PW / 2, cy - PH / 2 - 7);
    }
  }

  function draw() {
    ctx.setTransform(canvas.width / W, 0, 0, canvas.height / H, 0, 0);
    ctx.clearRect(0, 0, W, H);
    ctx.save();
    rr(0, 0, W, H, 22);
    ctx.clip();

    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#060a1e'); bg.addColorStop(1, '#0c0b26');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = 'rgba(120,150,255,0.07)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 40; x < W; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
    for (let y = 40; y < H; y += 40) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
    ctx.stroke();

    // faint giant scores
    ctx.font = '900 150px ui-monospace, Consolas, monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(0,240,255,0.06)';
    ctx.fillText(srv.sc[0], W * 0.25, H * 0.62);
    ctx.fillStyle = 'rgba(177,77,255,0.07)';
    ctx.fillText(srv.sc[1], W * 0.75, H * 0.62);

    // dashed centre line
    ctx.setLineDash([12, 14]);
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(W / 2, 14); ctx.lineTo(W / 2, H - 14); ctx.stroke();
    ctx.setLineDash([]);

    if (flash > 0) {
      ctx.fillStyle = COL[flashSlot - 1];
      ctx.globalAlpha = flash * 0.16;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
    }

    paddle(M, view.p1, COL[0], pulse[0], mySlot === 1);
    paddle(W - M - PW, view.p2, COL[1], pulse[1], mySlot === 2);

    // ball trail + ball
    for (let i = trail.length - 1; i >= 0; i--) {
      const t = trail[i];
      ctx.globalAlpha = (1 - i / trail.length) * 0.35;
      ctx.fillStyle = '#9fd8ff';
      ctx.beginPath(); ctx.arc(t.x, t.y, BR * (1 - i / (trail.length * 1.6)), 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.save();
    ctx.shadowColor = '#7ff6ff';
    ctx.shadowBlur = 24;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(view.bx, view.by, BR, 0, Math.PI * 2); ctx.fill();
    ctx.restore();

    Particles.draw(ctx);

    if (srv.st === 'COUNTDOWN' && srv.cd > 0) {
      const n = Math.ceil(srv.cd), frac = n - srv.cd;
      ctx.save();
      ctx.globalAlpha = 1 - frac * 0.7;
      ctx.font = '900 ' + Math.round(130 - frac * 22) + 'px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 34;
      ctx.fillText(n, W / 2, H / 2 + 44);
      ctx.restore();
    }
    ctx.restore();

    // neon border
    const bd = ctx.createLinearGradient(0, 0, W, 0);
    bd.addColorStop(0, COL[0]); bd.addColorStop(1, COL[1]);
    ctx.save();
    ctx.strokeStyle = bd;
    ctx.lineWidth = 4;
    ctx.shadowColor = '#7e8cff';
    ctx.shadowBlur = 22;
    rr(2, 2, W - 4, H - 4, 20);
    ctx.stroke();
    ctx.restore();
  }

  function frame(ts) {
    if (!running) return;
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (ts - lastTs) / 1000 || 0.016);
    lastTs = ts;
    update(dt);
    draw();
  }

  return {
    init, arenaY, setRoom, applyState,
    setMe(slot) { mySlot = slot; },
    status() { return srv.st; },
    start() {
      if (running) return;
      running = true; lastTs = performance.now();
      requestAnimationFrame(resize);
      raf = requestAnimationFrame(frame);
    },
    stop() { running = false; cancelAnimationFrame(raf); Particles.clear(); },
    updateOverlay
  };
})();
