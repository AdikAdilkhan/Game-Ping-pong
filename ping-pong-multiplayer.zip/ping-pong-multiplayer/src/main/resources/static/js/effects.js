'use strict';
/* Sound (Web Audio, no asset files), particles, animated background and confetti. */

const Sound = (() => {
  let ctx = null;
  let enabled = true;
  const listeners = [];
  try { const v = localStorage.getItem('pong.sound'); if (v !== null) enabled = v === '1'; } catch (e) { /* storage blocked */ }

  function ensure() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, dur, type, vol, slideTo, delay) {
    if (!enabled) return;
    const c = ensure();
    if (!c) return;
    const t = c.currentTime + (delay || 0);
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.12, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(c.destination);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  return {
    get enabled() { return enabled; },
    setEnabled(v) {
      enabled = !!v;
      try { localStorage.setItem('pong.sound', enabled ? '1' : '0'); } catch (e) { /* ignore */ }
      listeners.forEach(f => f(enabled));
      if (enabled) tone(660, 0.08, 'sine', 0.08);
    },
    onChange(f) { listeners.push(f); },
    unlock() { if (enabled) ensure(); },
    paddle() { tone(440, 0.09, 'square', 0.07, 880); },
    wall() { tone(220, 0.07, 'triangle', 0.12, 160); },
    score() { tone(520, 0.12, 'sawtooth', 0.07, 260); tone(260, 0.25, 'sawtooth', 0.06, 130, 0.1); },
    count() { tone(660, 0.12, 'sine', 0.14); },
    go() { tone(990, 0.3, 'sine', 0.16); },
    win() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.3, 'triangle', 0.14, null, i * 0.13)); }
  };
})();

const Particles = (() => {
  const list = [];
  return {
    burst(x, y, color, n, speed, life) {
      n = n || 14; speed = speed || 220; life = life || 0.5;
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = speed * (0.3 + Math.random() * 0.9);
        list.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, max: life, color, size: 1.5 + Math.random() * 2.5 });
      }
      if (list.length > 400) list.splice(0, list.length - 400);
    },
    update(dt) {
      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        p.life -= dt;
        if (p.life <= 0) { list.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt;
        p.vx *= 1 - 1.6 * dt; p.vy *= 1 - 1.6 * dt;
      }
    },
    draw(ctx) {
      for (const p of list) {
        ctx.globalAlpha = Math.max(0, p.life / p.max);
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
    },
    clear() { list.length = 0; }
  };
})();

/* Drifting neon orbs + a slowly scrolling grid. Paused during matches to save battery. */
const Background = (() => {
  const cv = document.getElementById('bg');
  const ctx = cv.getContext('2d');
  let w = 0, h = 0, t = 0, running = true, orbs = [];

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    cv.width = w * dpr; cv.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    orbs = Array.from({ length: 6 }, (_, i) => ({
      x: Math.random() * w, y: Math.random() * h, r: 140 + Math.random() * 180,
      vx: (Math.random() - 0.5) * 16, vy: (Math.random() - 0.5) * 16, c: i % 2 ? '177,77,255' : '0,240,255'
    }));
    if (!running) drawFrame(0);
  }

  function drawFrame(dt) {
    t += dt;
    ctx.clearRect(0, 0, w, h);
    for (const o of orbs) {
      o.x += o.vx * dt; o.y += o.vy * dt;
      if (o.x < -100 || o.x > w + 100) o.vx *= -1;
      if (o.y < -100 || o.y > h + 100) o.vy *= -1;
      const g = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, o.r);
      g.addColorStop(0, 'rgba(' + o.c + ',0.16)');
      g.addColorStop(1, 'rgba(' + o.c + ',0)');
      ctx.fillStyle = g;
      ctx.fillRect(o.x - o.r, o.y - o.r, o.r * 2, o.r * 2);
    }
    ctx.strokeStyle = 'rgba(120,150,255,0.07)';
    ctx.lineWidth = 1;
    const step = 56, off = (t * 12) % step;
    ctx.beginPath();
    for (let x = -off; x < w; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
    for (let y = off; y < h; y += step) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
    ctx.stroke();
  }

  let last = 0;
  function loop(ts) {
    if (!running) return;
    const dt = Math.min(0.05, (ts - last) / 1000 || 0.016);
    last = ts;
    drawFrame(dt);
    requestAnimationFrame(loop);
  }

  window.addEventListener('resize', resize);
  resize();
  requestAnimationFrame(loop);

  return {
    setPaused(p) {
      if (p === !running) return;
      running = !p;
      if (running) { last = performance.now(); requestAnimationFrame(loop); }
    }
  };
})();

/* Full-screen confetti for the game-over screen. */
const Confetti = (() => {
  const cv = document.getElementById('fx');
  const ctx = cv.getContext('2d');
  let pieces = [], active = false, last = 0;
  const colors = ['#00f0ff', '#b14dff', '#ff3ea5', '#ffcf4d', '#2dffa0', '#ffffff'];

  function size() { cv.width = window.innerWidth; cv.height = window.innerHeight; }
  window.addEventListener('resize', size);
  size();

  function loop(ts) {
    const dt = Math.min(0.05, (ts - last) / 1000 || 0.016);
    last = ts;
    ctx.clearRect(0, 0, cv.width, cv.height);
    for (let i = pieces.length - 1; i >= 0; i--) {
      const p = pieces[i];
      p.vy += 420 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      if (p.y > cv.height + 30) { pieces.splice(i, 1); continue; }
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.color; ctx.shadowColor = p.color; ctx.shadowBlur = 8;
      ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
      ctx.restore();
    }
    if (pieces.length) requestAnimationFrame(loop);
    else { active = false; ctx.clearRect(0, 0, cv.width, cv.height); }
  }

  return {
    burst(count) {
      for (let i = 0; i < count; i++) {
        pieces.push({
          x: cv.width / 2 + (Math.random() - 0.5) * cv.width * 0.5, y: cv.height * 0.25,
          vx: (Math.random() - 0.5) * 700, vy: -300 - Math.random() * 500,
          s: 6 + Math.random() * 8, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 14,
          color: colors[(Math.random() * colors.length) | 0]
        });
      }
      if (!active) { active = true; last = performance.now(); requestAnimationFrame(loop); }
    }
  };
})();
