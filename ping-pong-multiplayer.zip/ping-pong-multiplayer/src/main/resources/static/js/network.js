'use strict';
/* REST helpers + a WebSocket client with heartbeat and automatic reconnection. */

const Net = (() => {
  const MAX_ATTEMPTS = 10;
  const FATAL = new Set(['ROOM_NOT_FOUND', 'INVALID_PLAYER', 'REPLACED']);
  const handlers = {};
  let ws = null, session = null, attempts = 0, retryTimer = null, pingTimer = null, closedByUser = false, everOpened = false;

  function emit(type, data) { (handlers[type] || []).forEach(fn => fn(data)); }
  function on(type, fn) { (handlers[type] = handlers[type] || []).push(fn); }

  // ---------------------------------------------------------------- REST
  async function api(path, body) {
    let res;
    try {
      res = await fetch('/api' + path, body === undefined ? {} : {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
      });
    } catch (e) {
      const err = new Error('Server unavailable. Check that the game server is running and you are on the same Wi-Fi.');
      err.code = 'SERVER_UNAVAILABLE';
      throw err;
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) {
      const err = new Error((data && data.message) || 'Something went wrong (' + res.status + ').');
      err.code = (data && data.error) || 'HTTP_' + res.status;
      throw err;
    }
    return data;
  }

  // ---------------------------------------------------------------- WebSocket
  function connect(code, playerId) {
    closedByUser = false;
    attempts = 0;
    session = { code, playerId };
    try { sessionStorage.setItem('pong.session', JSON.stringify(session)); } catch (e) { /* ignore */ }
    open();
  }

  function open() {
    clearTimeout(retryTimer);
    if (ws) { ws.onclose = null; try { ws.close(); } catch (e) { /* ignore */ } }
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host + '/ws');
    ws.onopen = () => {
      everOpened = true;
      send({ type: 'join', code: session.code, playerId: session.playerId });
      clearInterval(pingTimer);
      pingTimer = setInterval(() => send({ type: 'ping', t: Date.now() }), 3000);
    };
    ws.onmessage = (ev) => {
      let m;
      try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (m.type === 'welcome') { attempts = 0; }
      if (m.type === 'pong') { emit('latency', Date.now() - m.t); return; }
      if (m.type === 'error' && FATAL.has(m.code)) { closedByUser = true; forget(); }
      if (m.type === 'closed') { closedByUser = true; forget(); }
      emit(m.type, m);
    };
    ws.onclose = () => {
      clearInterval(pingTimer);
      if (closedByUser || !session) return;
      scheduleReconnect();
    };
    ws.onerror = () => { /* onclose follows */ };
  }

  function scheduleReconnect() {
    attempts++;
    if (attempts > MAX_ATTEMPTS) {
      forget();
      emit('lost', { everOpened });
      return;
    }
    emit('reconnecting', { attempt: attempts, max: MAX_ATTEMPTS });
    retryTimer = setTimeout(open, Math.min(500 * attempts, 3000));
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) { ws.send(JSON.stringify(obj)); return true; }
    return false;
  }

  function forget() {
    session = null;
    try { sessionStorage.removeItem('pong.session'); } catch (e) { /* ignore */ }
  }

  function leave() {
    send({ type: 'leave' });
    closedByUser = true;
    clearTimeout(retryTimer);
    clearInterval(pingTimer);
    forget();
    if (ws) { try { ws.close(); } catch (e) { /* ignore */ } }
  }

  function savedSession() {
    try { return JSON.parse(sessionStorage.getItem('pong.session')); } catch (e) { return null; }
  }

  return {
    on, send, connect, leave, savedSession,
    createRoom: (nickname) => api('/rooms', { nickname }),
    joinRoom: (code, nickname) => api('/rooms/' + encodeURIComponent(code) + '/join', { nickname }),
    quickPlay: (nickname) => api('/rooms/quick', { nickname }),
    network: () => api('/network')
  };
})();
