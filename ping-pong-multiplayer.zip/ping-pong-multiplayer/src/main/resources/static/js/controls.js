'use strict';
/* Keyboard, mouse and touch input. A device only ever steers its own paddle:
   the server decides which paddle that is from the authenticated connection. */

const Controls = (() => {
  const UP = new Set(['KeyW', 'ArrowUp']);
  const DOWN = new Set(['KeyS', 'ArrowDown']);
  const pressed = new Set();
  let enabled = false, dir = 0, lastY = 0, getArenaY = () => 250, element = null;

  function sendDir(d) {
    if (d === dir) return;
    dir = d;
    Net.send({ type: 'input', dir: d });
  }

  function refreshKeys() {
    let up = false, down = false;
    pressed.forEach(c => { if (UP.has(c)) up = true; if (DOWN.has(c)) down = true; });
    sendDir((down ? 1 : 0) - (up ? 1 : 0));
  }

  function pointer(e) {
    if (!enabled || pressed.size > 0) return;
    if (e.target && e.target.closest && e.target.closest('.overlay')) return; // let the Resume button work
    const now = performance.now();
    if (now - lastY < 14) return; // ~70 messages per second max
    lastY = now;
    dir = 0; // server clears the direction when a target arrives
    Net.send({ type: 'input', y: getArenaY(e.clientY) });
  }

  function init(opts) {
    element = opts.element;
    getArenaY = opts.getArenaY;

    window.addEventListener('keydown', (e) => {
      if (!enabled || e.repeat) { if (enabled && (UP.has(e.code) || DOWN.has(e.code))) e.preventDefault(); return; }
      if (UP.has(e.code) || DOWN.has(e.code)) { e.preventDefault(); pressed.add(e.code); refreshKeys(); }
    });
    window.addEventListener('keyup', (e) => {
      if (pressed.delete(e.code)) refreshKeys();
    });
    window.addEventListener('blur', () => { pressed.clear(); sendDir(0); });

    // Pointer events cover mouse and touch. touch-action:none (CSS) lets a vertical drag reach us.
    element.addEventListener('pointerdown', (e) => { if (e.target.closest && e.target.closest('.overlay')) return; try { element.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } pointer(e); });
    element.addEventListener('pointermove', pointer);
    // iOS Safari still tries to scroll/bounce: block it while a match screen is shown.
    document.addEventListener('touchmove', (e) => { if (enabled) e.preventDefault(); }, { passive: false });
    document.addEventListener('gesturestart', (e) => { if (enabled) e.preventDefault(); });
  }

  return {
    init,
    setEnabled(v) {
      if (enabled === v) return;
      enabled = v;
      if (!v) { pressed.clear(); sendDir(0); }
    }
  };
})();
