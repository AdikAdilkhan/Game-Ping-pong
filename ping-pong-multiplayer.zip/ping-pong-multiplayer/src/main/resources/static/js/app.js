'use strict';
/* Screen flow, lobby logic and wiring between UI and network. */

(() => {
  const $ = (s) => document.querySelector(s);
  const SCREENS = ['home', 'create', 'join', 'lobby', 'game', 'over'];
  const FATAL_ERRORS = new Set(['ROOM_NOT_FOUND', 'INVALID_PLAYER', 'REPLACED']);

  let current = 'home';
  let room = null;
  let me = { slot: 0, host: false };
  let netInfo = null;
  let pendingCode = null;
  let joinMode = 'join';
  let wasReconnecting = false;
  let hintedRotate = false;

  // ------------------------------------------------------------------ helpers
  function show(name) {
    current = name;
    SCREENS.forEach(s => $('#screen-' + s).classList.toggle('active', s === name));
    document.body.classList.toggle('in-game', name === 'game');
    Background.setPaused(name === 'game');
    Controls.setEnabled(name === 'game');
    if (name === 'game') Game.start(); else Game.stop();
  }

  function toast(text, kind) {
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = text; // textContent: nicknames and server text can never inject HTML
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), 4500);
  }

  function banner(text, kind) {
    const b = $('#conn-banner');
    if (!text) { b.classList.add('hidden'); return; }
    b.textContent = text;
    b.className = 'banner ' + (kind || '');
  }

  function setError(sel, text) { $(sel).textContent = text || ''; }

  function copy(text, okMsg) {
    const done = () => toast(okMsg, 'ok');
    // navigator.clipboard needs HTTPS; plain http://192.168.x.x pages need the fallback.
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
    } else {
      fallbackCopy(text, done);
    }
  }
  function fallbackCopy(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { toast('Copy failed - select the text manually.', 'error'); }
    ta.remove();
  }

  function savedNick() { try { return localStorage.getItem('pong.nick') || ''; } catch (e) { return ''; } }
  function saveNick(n) { try { localStorage.setItem('pong.nick', n); } catch (e) { /* ignore */ } }

  function resetToHome(message, kind) {
    room = null; pendingCode = null;
    banner(null);
    wasReconnecting = false;
    $('#join-loading').classList.add('hidden');
    $('#btn-join-submit').disabled = false;
    $('#btn-create-submit').disabled = false;
    $('#create-form').classList.remove('hidden');
    $('#create-wait').classList.add('hidden');
    show('home');
    if (message) toast(message, kind || 'warn');
  }

  // ------------------------------------------------------------------ home
  function loadNetworkInfo() {
    return Net.network().then(info => {
      netInfo = info;
      const el = $('#home-net');
      if (info.urls && info.urls.length) {
        el.textContent = 'This server is reachable at ' + info.urls.join('  or  ') + ' - open that address on the other device.';
      } else {
        el.textContent = 'No Wi-Fi/LAN address detected on the server. Connect it to your Wi-Fi and restart.';
      }
    }).catch(() => { $('#home-net').textContent = 'Server unavailable right now.'; });
  }

  $('#btn-create').onclick = () => { setError('#create-error'); $('#create-nick').value = savedNick(); show('create'); $('#create-nick').focus(); };
  $('#btn-join').onclick = () => openJoin('join');
  $('#btn-play-online').onclick = () => openJoin('quick');

  function openJoin(mode) {
    joinMode = mode;
    $('#join-title').textContent = mode === 'quick' ? 'Play online' : 'Join room';
    $('#btn-join-submit').textContent = mode === 'quick' ? 'FIND MATCH' : 'JOIN ROOM';
    $('#join-code-field').classList.toggle('hidden', mode === 'quick');
    $('#join-nick').value = savedNick();
    setError('#join-error');
    show('join');
    $('#join-nick').focus();
  }

  const optSound = $('#opt-sound');
  optSound.checked = Sound.enabled;
  optSound.onchange = () => Sound.setEnabled(optSound.checked);
  function syncSoundUi(on) {
    optSound.checked = on;
    $('#btn-sound').innerHTML = (on ? '&#128266;' : '&#128263;') + ' <span>Sound</span>';
  }
  Sound.onChange(syncSoundUi);
  syncSoundUi(Sound.enabled);
  $('#btn-sound').onclick = () => Sound.setEnabled(!Sound.enabled);
  document.addEventListener('pointerdown', () => Sound.unlock(), { once: true });

  // ------------------------------------------------------------------ create
  $('#btn-create-back').onclick = () => show('home');
  $('#create-nick').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btn-create-submit').click(); });
  $('#btn-create-submit').onclick = async () => {
    const nick = $('#create-nick').value.trim();
    if (!nick) { setError('#create-error', 'Please enter a nickname.'); return; }
    setError('#create-error');
    $('#btn-create-submit').disabled = true;
    try {
      saveNick(nick);
      startSession(await Net.createRoom(nick));
    } catch (e) {
      setError('#create-error', e.message);
      $('#btn-create-submit').disabled = false;
    }
  };
  $('#btn-create-cancel').onclick = leaveRoom;
  $('#btn-copy-code').onclick = () => copy($('#room-code').textContent, 'Room code copied');
  $('#btn-copy-url').onclick = () => copy($('#lan-url').dataset.url || $('#lan-url').textContent, 'Address copied');

  function fillCreateWait() {
    const code = (room && room.code) || pendingCode || '------';
    $('#room-code').textContent = code;
    const urls = netInfo && netInfo.urls ? netInfo.urls : [];
    const box = $('#lan-url');
    if (urls.length) {
      box.textContent = urls.join('\n');
      box.style.whiteSpace = 'pre-line';
      box.dataset.url = urls[0];
      $('#lan-hint').textContent = urls.length > 1 ? 'Several networks found - use the one on your Wi-Fi.' : 'Open this on the other device (same Wi-Fi).';
    } else {
      box.textContent = 'No LAN address found';
      box.dataset.url = '';
      $('#lan-hint').textContent = 'Connect this computer to Wi-Fi, restart the server, and find your IPv4 address (see README).';
    }
    const n = room ? room.players.filter(p => p && p.connected).length : 1;
    $('#create-players').textContent = n + '/2';
    $('#create-form').classList.add('hidden');
    $('#create-wait').classList.remove('hidden');
  }

  // ------------------------------------------------------------------ join
  $('#btn-join-back').onclick = () => show('home');
  $('#join-code').addEventListener('input', (e) => {
    e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  });
  ['#join-nick', '#join-code'].forEach(sel => $(sel).addEventListener('keydown', e => { if (e.key === 'Enter') $('#btn-join-submit').click(); }));

  $('#btn-join-submit').onclick = async () => {
    const nick = $('#join-nick').value.trim();
    const code = $('#join-code').value.trim().toUpperCase();
    if (!nick) { setError('#join-error', 'Please enter a nickname.'); return; }
    if (joinMode === 'join' && !/^[A-HJ-NP-Z2-9]{6}$/.test(code)) { setError('#join-error', 'Invalid room code - it has 6 letters or digits.'); return; }
    setError('#join-error');
    $('#btn-join-submit').disabled = true;
    $('#join-loading').classList.remove('hidden');
    try {
      saveNick(nick);
      const r = joinMode === 'quick' ? await Net.quickPlay(nick) : await Net.joinRoom(code, nick);
      startSession(r);
    } catch (e) {
      $('#join-loading').classList.add('hidden');
      $('#btn-join-submit').disabled = false;
      setError('#join-error', e.message);
    }
  };

  function startSession(r) {
    me = { slot: r.slot, host: r.host };
    netInfo = r.network || netInfo;
    pendingCode = r.code;
    Game.setMe(r.slot);
    Net.connect(r.code, r.playerId);
    if (r.host) { room = null; fillCreateWait(); show('create'); }
    // a guest stays on the join screen (loading) until the first room message arrives
  }

  // ------------------------------------------------------------------ lobby
  function renderLobby() {
    $('#lobby-code').textContent = room.code;
    for (let i = 1; i <= 2; i++) {
      const card = $('#lobby-p' + i);
      const p = room.players[i - 1];
      card.classList.toggle('empty', !p);
      card.querySelector('.pname').textContent = p ? p.nickname + (i === me.slot ? ' (you)' : '') : 'Waiting...';
      card.querySelector('.dot').className = 'dot ' + (!p ? 'wait' : p.connected ? 'on' : 'off');
      card.querySelector('.ptext').textContent = !p ? 'Not connected' : p.connected ? 'Connected' : 'Reconnecting...';
      const badge = card.querySelector('.badge');
      if (i === 2) {
        badge.textContent = p ? (p.ready ? 'READY' : 'NOT READY') : '';
        badge.classList.toggle('ready', !!(p && p.ready));
      } else {
        badge.textContent = 'HOST';
        badge.classList.add('ready');
      }
    }
    $('#target-seg').classList.toggle('locked', !me.host);
    $('#target-seg').querySelectorAll('button').forEach(b => b.classList.toggle('active', +b.dataset.v === room.targetScore));

    const guest = room.players[1];
    const startBtn = $('#btn-start'), readyBtn = $('#btn-ready');
    startBtn.classList.toggle('hidden', !me.host);
    readyBtn.classList.toggle('hidden', me.host);
    if (me.host) {
      const ok = !!(guest && guest.connected && guest.ready && room.players[0].connected);
      startBtn.disabled = !ok;
      $('#lobby-hint').textContent = ok ? 'Everyone is ready - start when you like!' : (guest && guest.connected ? 'Waiting for ' + guest.nickname + ' to press READY...' : 'Waiting for your opponent to connect...');
    } else {
      const ready = !!(guest && guest.ready);
      readyBtn.textContent = ready ? 'NOT READY' : "I'M READY";
      $('#lobby-hint').textContent = ready ? 'Waiting for the host to start the match...' : 'Press READY when you are set.';
    }
  }

  $('#target-seg').querySelectorAll('button').forEach(b => {
    b.onclick = () => { if (me.host) Net.send({ type: 'settings', targetScore: +b.dataset.v }); };
  });
  $('#btn-ready').onclick = () => {
    const guest = room && room.players[1];
    Net.send({ type: 'ready', ready: !(guest && guest.ready) });
  };
  $('#btn-start').onclick = () => Net.send({ type: 'start' });
  $('#btn-leave').onclick = leaveRoom;

  function leaveRoom() {
    Net.leave();
    resetToHome();
  }

  // ------------------------------------------------------------------ game controls
  $('#btn-pause').onclick = togglePause;
  $('#btn-resume').onclick = () => Net.send({ type: 'resume' });
  $('#btn-restart').onclick = () => { if (confirm('Restart the match from 0:0?')) Net.send({ type: 'restart' }); };
  $('#btn-quit').onclick = () => { if (confirm('Leave the match? Your opponent will be notified.')) leaveRoom(); };
  window.addEventListener('keydown', (e) => {
    if (current !== 'game' || e.repeat) return;
    if (e.code === 'KeyP' || e.code === 'Escape') togglePause();
  });
  function togglePause() {
    const st = Game.status();
    if (st === 'PLAYING') Net.send({ type: 'pause' });
    else if (st === 'PAUSED') Net.send({ type: 'resume' });
  }

  // ------------------------------------------------------------------ game over
  function renderOver() {
    const w = room.winner;
    const winner = room.players[w - 1];
    $('#winner-text').textContent = w === me.slot ? 'YOU WIN!' : (winner ? winner.nickname + ' wins' : 'Game over');
    $('#final1').textContent = room.score[0];
    $('#final2').textContent = room.score[1];
    $('#final-names').textContent = room.players.map(p => p ? p.nickname : '-').join('  vs  ');
    const mine = room.players[me.slot - 1], theirs = room.players[me.slot === 1 ? 1 : 0];
    const btn = $('#btn-again');
    btn.disabled = !!(mine && mine.rematch);
    btn.textContent = mine && mine.rematch ? 'WAITING FOR OPPONENT...' : 'PLAY AGAIN';
    $('#rematch-hint').textContent = theirs && theirs.rematch && !(mine && mine.rematch) ? theirs.nickname + ' wants a rematch!' : '';
  }
  $('#btn-again').onclick = () => Net.send({ type: 'rematch' });
  $('#btn-home').onclick = leaveRoom;

  // ------------------------------------------------------------------ routing by server status
  function route() {
    const st = room.status;
    $('#btn-restart').classList.toggle('hidden', !me.host);
    if (st === 'LOBBY') {
      if (me.host && !room.players[1]) { fillCreateWait(); show('create'); }
      else { renderLobby(); show('lobby'); }
    } else if (st === 'GAME_OVER') {
      const first = current !== 'over';
      renderOver();
      show('over');
      if (first) {
        Confetti.burst(room.winner === me.slot ? 220 : 60);
      }
    } else {
      const entering = current !== 'game';
      if (entering) Particles.clear();
      show('game');
      if (entering && !hintedRotate && window.innerHeight > window.innerWidth && navigator.maxTouchPoints > 0) {
        hintedRotate = true;
        toast('Tip: rotate your phone to landscape for a bigger arena.', 'ok');
      }
    }
  }

  // ------------------------------------------------------------------ network events
  Net.on('welcome', (m) => {
    me = { slot: m.slot, host: m.host };
    Game.setMe(m.slot);
    if (wasReconnecting) { toast('Reconnected', 'ok'); wasReconnecting = false; }
    banner(null);
  });
  Net.on('room', (m) => {
    room = m;
    $('#join-loading').classList.add('hidden');
    $('#btn-join-submit').disabled = false;
    Game.setRoom(m);
    route();
  });
  Net.on('state', (m) => Game.applyState(m));
  Net.on('notice', (m) => {
    const kind = /DISCONNECT|LEFT/.test(m.code) ? 'warn' : 'ok';
    toast(m.message, kind);
  });
  Net.on('error', (m) => {
    if (FATAL_ERRORS.has(m.code)) resetToHome(m.message, 'error');
    else toast(m.message, 'error');
  });
  Net.on('closed', (m) => resetToHome(m.message || 'The room was closed.', 'warn'));
  Net.on('reconnecting', (m) => {
    wasReconnecting = true;
    banner('Connection lost - reconnecting (' + m.attempt + '/' + m.max + ')...');
  });
  Net.on('lost', (m) => resetToHome(m.everOpened ? 'Connection lost. Please rejoin the room.' : 'Server unavailable. Check the address and Wi-Fi.', 'error'));
  Net.on('latency', (ms) => { $('#hud-ping').textContent = ms + ' ms'; });

  // ------------------------------------------------------------------ boot
  Game.init();
  Controls.init({ element: $('#arena-box'), getArenaY: (y) => Game.arenaY(y) });
  loadNetworkInfo();

  const saved = Net.savedSession();
  if (saved && saved.code && saved.playerId) {
    // Page was reloaded in the middle of a room: try to take the same seat back.
    wasReconnecting = true;
    pendingCode = saved.code;
    banner('Reconnecting to your room...');
    Net.connect(saved.code, saved.playerId);
  }
})();
