Sound effects are synthesized at runtime with the Web Audio API (see js/effects.js),
so no audio files are needed and nothing is downloaded.
