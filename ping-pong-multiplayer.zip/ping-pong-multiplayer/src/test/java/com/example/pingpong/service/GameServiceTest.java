package com.example.pingpong.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.example.pingpong.model.GameRoom;
import com.example.pingpong.model.GameStatus;
import com.example.pingpong.service.RoomService.Joined;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

class GameServiceTest {
    private final ObjectMapper mapper = new ObjectMapper();
    private RoomService rooms;
    private GameService game;
    private Joined host;
    private Joined guest;
    private Fake hostWs;
    private Fake guestWs;
    private GameRoom room;
    private long clock = System.nanoTime();

    /** A mocked WebSocketSession that records everything the server sends to it. */
    private class Fake {
        final WebSocketSession session = mock(WebSocketSession.class);
        final List<JsonNode> received = new ArrayList<>();

        Fake(String id) throws Exception {
            when(session.getId()).thenReturn(id);
            when(session.isOpen()).thenReturn(true);
            doAnswer(inv -> {
                received.add(mapper.readTree(((TextMessage) inv.getArgument(0)).getPayload()));
                return null;
            }).when(session).sendMessage(any());
        }

        JsonNode last(String type) {
            for (int i = received.size() - 1; i >= 0; i--) {
                if (received.get(i).path("type").asText().equals(type)) return received.get(i);
            }
            return null;
        }

        boolean gotError(String code) {
            return received.stream().anyMatch(m -> m.path("type").asText().equals("error") && m.path("code").asText().equals(code));
        }
    }

    private JsonNode json(String s) throws Exception { return mapper.readTree(s); }

    @BeforeEach
    void setUp() throws Exception {
        rooms = new RoomService();
        game = new GameService(rooms, mapper, 60, 1, 30);
        host = rooms.createRoom("Alice", false);
        guest = rooms.joinRoom(host.room().getCode(), "Bob");
        room = host.room();
        hostWs = new Fake("h1");
        guestWs = new Fake("g1");
        game.attach(hostWs.session, room.getCode(), host.player().getId());
        game.attach(guestWs.session, room.getCode(), guest.player().getId());
    }

    private void startMatch() throws Exception {
        game.onMessage(guestWs.session, json("{\"type\":\"ready\",\"ready\":true}"));
        game.onMessage(hostWs.session, json("{\"type\":\"start\"}"));
    }

    /** Advances the game loop by n ticks of 1/60 s. */
    private void runTicks(int n) {
        long millis = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            clock += 16_666_667L; // monotonic fake clock shared by all calls
            game.tick(clock, millis);
        }
    }

    @Test
    void bothPlayersAreToldTheyAreConnected() {
        JsonNode r = hostWs.last("room");
        assertTrue(r.get("players").get(0).get("connected").asBoolean());
        assertTrue(r.get("players").get(1).get("connected").asBoolean());
        assertEquals(2, guestWs.last("welcome").get("slot").asInt());
    }

    @Test
    void joinWithWrongTokenIsRejected() throws Exception {
        Fake intruder = new Fake("x1");
        game.attach(intruder.session, room.getCode(), "not-a-real-token");
        assertTrue(intruder.gotError("INVALID_PLAYER"));
        verify(intruder.session).close(any());
    }

    @Test
    void joinUnknownRoomIsRejected() throws Exception {
        Fake f = new Fake("x2");
        game.attach(f.session, "ZZZZZZ", host.player().getId());
        assertTrue(f.gotError("ROOM_NOT_FOUND"));
    }

    @Test
    void onlyHostMayStartAndGuestMustBeReady() throws Exception {
        game.onMessage(guestWs.session, json("{\"type\":\"start\"}"));
        assertTrue(guestWs.gotError("NOT_HOST"));
        game.onMessage(hostWs.session, json("{\"type\":\"start\"}"));
        assertTrue(hostWs.gotError("NOT_READY"));
        assertEquals(GameStatus.LOBBY, room.getState().status);
        startMatch();
        assertEquals(GameStatus.COUNTDOWN, room.getState().status);
    }

    @Test
    void settingsAreHostOnlyAndValidated() throws Exception {
        game.onMessage(guestWs.session, json("{\"type\":\"settings\",\"targetScore\":10}"));
        assertTrue(guestWs.gotError("NOT_HOST"));
        game.onMessage(hostWs.session, json("{\"type\":\"settings\",\"targetScore\":99}"));
        assertTrue(hostWs.gotError("INVALID_SETTING"));
        game.onMessage(hostWs.session, json("{\"type\":\"settings\",\"targetScore\":7}"));
        assertEquals(7, room.getState().targetScore);
    }

    @Test
    void eachPlayerOnlyControlsTheirOwnPaddle() throws Exception {
        startMatch();
        runTicks(200); // countdown finishes
        double p1 = room.getState().paddle1Y;
        double p2 = room.getState().paddle2Y;
        game.onMessage(guestWs.session, json("{\"type\":\"input\",\"dir\":-1}"));
        runTicks(10);
        assertEquals(p1, room.getState().paddle1Y, 0.0001, "guest must not move the host paddle");
        assertTrue(room.getState().paddle2Y < p2, "guest moves paddle 2");
    }

    @Test
    void injectedSlotInMessageIsIgnored() throws Exception {
        startMatch();
        runTicks(200);
        double p1 = room.getState().paddle1Y;
        game.onMessage(guestWs.session, json("{\"type\":\"input\",\"dir\":1,\"slot\":1,\"playerId\":\"" + host.player().getId() + "\"}"));
        runTicks(10);
        assertEquals(p1, room.getState().paddle1Y, 0.0001);
    }

    @Test
    void invalidMessagesAreRejectedSafely() throws Exception {
        game.onMessage(hostWs.session, json("{\"type\":\"input\",\"dir\":5}"));
        assertTrue(hostWs.gotError("INVALID_INPUT"));
        game.onMessage(hostWs.session, json("{\"type\":\"input\",\"dir\":\"up\"}"));
        game.onMessage(hostWs.session, json("{\"type\":\"explode\"}"));
        assertTrue(hostWs.gotError("UNKNOWN_ACTION"));
        game.onMessage(hostWs.session, json("{}"));
        // an unbound socket cannot do anything
        Fake stranger = new Fake("s9");
        game.onMessage(stranger.session, json("{\"type\":\"start\"}"));
        assertTrue(stranger.gotError("NOT_JOINED"));
        assertEquals(GameStatus.LOBBY, room.getState().status);
    }

    @Test
    void disconnectPausesRunningMatchAndReconnectResumes() throws Exception {
        startMatch();
        runTicks(200);
        assertEquals(GameStatus.PLAYING, room.getState().status);

        game.onClose(guestWs.session);
        assertEquals(GameStatus.PAUSED, room.getState().status);
        assertNotNull(hostWs.last("notice"));
        assertEquals("OPPONENT_DISCONNECTED", hostWs.last("notice").get("code").asText());
        assertFalse(hostWs.last("room").get("players").get(1).get("connected").asBoolean());

        Fake guestAgain = new Fake("g2");
        game.attach(guestAgain.session, room.getCode(), guest.player().getId());
        assertEquals(GameStatus.COUNTDOWN, room.getState().status, "match resumes through a countdown");
        assertEquals("OPPONENT_RECONNECTED", hostWs.last("notice").get("code").asText());
    }

    @Test
    void newConnectionReplacesDuplicateSession() throws Exception {
        Fake second = new Fake("g3");
        game.attach(second.session, room.getCode(), guest.player().getId());
        assertTrue(guestWs.gotError("REPLACED"));
        verify(guestWs.session).close(any());
        // closing the old socket afterwards must not mark the player disconnected
        game.onClose(guestWs.session);
        assertTrue(guest.player().isConnected());
    }

    @Test
    void playerRemovedAfterGracePeriod() throws Exception {
        game.onClose(guestWs.session);
        game.tick(System.nanoTime(), System.currentTimeMillis() + 31_000);
        assertNull(room.player(2), "guest slot is freed");
        assertEquals(GameStatus.LOBBY, room.getState().status);
        assertEquals("OPPONENT_LEFT", hostWs.last("notice").get("code").asText());
    }

    @Test
    void hostLeavingClosesRoom() throws Exception {
        game.onMessage(hostWs.session, json("{\"type\":\"leave\"}"));
        assertTrue(rooms.find(room.getCode()).isEmpty());
        assertNotNull(guestWs.last("closed"));
    }

    @Test
    void completedMatchReportsGameOverAndAllowsRematch() throws Exception {
        startMatch();
        room.getState().score1 = room.getState().targetScore - 1;
        runTicks(200);
        // force a decisive point: ball already past player 2
        room.getState().ballX = 900;
        room.getState().ballVx = 400;
        runTicks(2);
        assertEquals(GameStatus.GAME_OVER, room.getState().status);
        assertEquals(1, hostWs.last("room").get("winner").asInt());

        game.onMessage(hostWs.session, json("{\"type\":\"rematch\"}"));
        assertEquals(GameStatus.GAME_OVER, room.getState().status, "needs both players");
        game.onMessage(guestWs.session, json("{\"type\":\"rematch\"}"));
        assertEquals(GameStatus.COUNTDOWN, room.getState().status);
        assertEquals(0, room.getState().score1);
    }
}
