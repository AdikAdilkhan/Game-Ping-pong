package com.example.pingpong.integration;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

/** Two real WebSocket clients playing against the real server on a random port. */
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class MultiplayerFlowTest {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @LocalServerPort int port;
    @Autowired TestRestTemplate rest;

    /** WebSocket client that queues every JSON message it receives. */
    static class Client implements WebSocket.Listener {
        final BlockingQueue<JsonNode> inbox = new LinkedBlockingQueue<>();
        private final StringBuilder buffer = new StringBuilder();
        WebSocket ws;

        @Override public void onOpen(WebSocket w) { w.request(1); }

        @Override public CompletionStage<?> onText(WebSocket w, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                try { inbox.add(MAPPER.readTree(buffer.toString())); } catch (Exception ignored) { }
                buffer.setLength(0);
            }
            w.request(1);
            return null;
        }

        void send(String json) { ws.sendText(json, true).join(); }

        JsonNode await(Predicate<JsonNode> match, long seconds) throws Exception {
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds);
            while (System.nanoTime() < end) {
                JsonNode m = inbox.poll(200, TimeUnit.MILLISECONDS);
                if (m != null && match.test(m)) return m;
            }
            fail("Timed out waiting for expected message");
            return null;
        }
    }

    private Client connect(String code, String playerId) throws Exception {
        Client c = new Client();
        c.ws = HttpClient.newHttpClient().newWebSocketBuilder()
                .buildAsync(URI.create("ws://localhost:" + port + "/ws"), c).get(5, TimeUnit.SECONDS);
        c.send("{\"type\":\"join\",\"code\":\"" + code + "\",\"playerId\":\"" + playerId + "\"}");
        return c;
    }

    @SuppressWarnings("unchecked")
    @Test
    void twoClientsCanCreateJoinAndPlayInRealTime() throws Exception {
        // --- REST: create, join, reject third player, unknown room
        ResponseEntity<Map> created = rest.postForEntity("/api/rooms", Map.of("nickname", "Alice"), Map.class);
        assertEquals(201, created.getStatusCode().value());
        String code = (String) created.getBody().get("code");
        String hostId = (String) created.getBody().get("playerId");
        assertEquals(6, code.length());

        ResponseEntity<Map> joined = rest.postForEntity("/api/rooms/" + code + "/join", Map.of("nickname", "Bob"), Map.class);
        assertEquals(200, joined.getStatusCode().value());
        String guestId = (String) joined.getBody().get("playerId");
        assertEquals(2, joined.getBody().get("slot"));

        ResponseEntity<Map> third = rest.postForEntity("/api/rooms/" + code + "/join", Map.of("nickname", "Eve"), Map.class);
        assertEquals(409, third.getStatusCode().value());
        assertEquals("ROOM_FULL", third.getBody().get("error"));

        ResponseEntity<Map> missing = rest.postForEntity("/api/rooms/ZZZZZZ/join", Map.of("nickname", "Eve"), Map.class);
        assertEquals(404, missing.getStatusCode().value());

        // --- WebSocket: both connect
        Client host = connect(code, hostId);
        Client guest = connect(code, guestId);
        Predicate<JsonNode> bothOnline = m -> m.path("type").asText().equals("room")
                && m.path("players").get(0).path("connected").asBoolean()
                && m.path("players").get(1).path("connected").asBoolean();
        host.await(bothOnline, 5);
        guest.await(bothOnline, 5);

        // --- lobby: guest ready, host starts
        guest.send("{\"type\":\"ready\",\"ready\":true}");
        host.await(m -> m.path("type").asText().equals("room") && m.path("players").get(1).path("ready").asBoolean(), 5);
        host.send("{\"type\":\"start\"}");
        host.await(m -> m.path("type").asText().equals("state") && m.path("st").asText().equals("COUNTDOWN"), 5);
        guest.await(m -> m.path("type").asText().equals("state") && m.path("st").asText().equals("COUNTDOWN"), 5);

        // --- both see PLAYING after the countdown
        JsonNode hostPlaying = host.await(m -> m.path("type").asText().equals("state") && m.path("st").asText().equals("PLAYING"), 8);
        guest.await(m -> m.path("type").asText().equals("state") && m.path("st").asText().equals("PLAYING"), 8);
        assertEquals(4, hostPlaying.get("b").size());

        // --- the host's input is visible on the GUEST's screen (server-authoritative sync)
        host.send("{\"type\":\"input\",\"dir\":-1}");
        JsonNode moved = guest.await(m -> m.path("type").asText().equals("state") && m.path("p").get(0).asDouble() < 200, 5);
        assertEquals(250.0, moved.path("p").get(1).asDouble(), 0.5, "the guest paddle did not move");
        host.send("{\"type\":\"input\",\"dir\":0}");

        host.ws.sendClose(1000, "bye");
        guest.ws.sendClose(1000, "bye");
    }
}
