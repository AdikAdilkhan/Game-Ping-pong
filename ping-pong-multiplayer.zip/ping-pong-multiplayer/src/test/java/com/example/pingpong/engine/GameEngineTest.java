package com.example.pingpong.engine;

import static com.example.pingpong.model.GameConstants.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.pingpong.model.GameEvent;
import com.example.pingpong.model.GameState;
import com.example.pingpong.model.GameStatus;
import com.example.pingpong.model.PlayerInput;
import java.util.List;
import java.util.Random;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GameEngineTest {
    private static final double DT = 1.0 / 60;

    private GameEngine engine;
    private GameState s;
    private PlayerInput in1;
    private PlayerInput in2;

    @BeforeEach
    void setUp() {
        engine = new GameEngine(new Random(42));
        s = new GameState();
        in1 = new PlayerInput();
        in2 = new PlayerInput();
        s.status = GameStatus.PLAYING;
        s.ballX = WIDTH / 2;
        s.ballY = HEIGHT / 2;
    }

    private static boolean has(List<GameEvent> events, String type) {
        return events.stream().anyMatch(e -> e.type().equals(type));
    }

    @Test
    void ballMovesAccordingToVelocity() {
        s.ballVx = 300;
        s.ballVy = 60;
        engine.update(s, in1, in2, 0.1);
        assertEquals(WIDTH / 2 + 30, s.ballX, 0.01);
        assertEquals(HEIGHT / 2 + 6, s.ballY, 0.01);
    }

    @Test
    void movementIsFrameRateIndependent() {
        s.ballVx = 300;
        GameState other = new GameState();
        other.status = GameStatus.PLAYING;
        other.ballVx = 300;
        for (int i = 0; i < 60; i++) engine.update(s, in1, in2, 1.0 / 60);
        for (int i = 0; i < 30; i++) engine.update(other, in1, in2, 1.0 / 30);
        assertEquals(s.ballX, other.ballX, 0.01);
    }

    @Test
    void topWallReflectsBall() {
        s.ballY = BALL_RADIUS + 1;
        s.ballVx = 100;
        s.ballVy = -400;
        List<GameEvent> ev = engine.update(s, in1, in2, DT);
        assertTrue(s.ballVy > 0, "ball must travel downward after the top wall");
        assertTrue(s.ballY >= BALL_RADIUS);
        assertTrue(has(ev, GameEvent.WALL));
    }

    @Test
    void bottomWallReflectsBall() {
        s.ballY = HEIGHT - BALL_RADIUS - 1;
        s.ballVx = 100;
        s.ballVy = 400;
        List<GameEvent> ev = engine.update(s, in1, in2, DT);
        assertTrue(s.ballVy < 0);
        assertTrue(s.ballY <= HEIGHT - BALL_RADIUS);
        assertTrue(has(ev, GameEvent.WALL));
    }

    @Test
    void leftPaddleReturnsBallAndSpeedsItUp() {
        s.paddle1Y = 250;
        s.ballX = PADDLE_MARGIN + PADDLE_WIDTH + BALL_RADIUS + 1;
        s.ballY = 250;
        s.ballVx = -400;
        s.ballVy = 0;
        List<GameEvent> ev = engine.update(s, in1, in2, DT);
        assertTrue(s.ballVx > 0, "ball must head right after a left paddle hit");
        assertTrue(Math.hypot(s.ballVx, s.ballVy) > 400, "rally speed should increase");
        assertTrue(has(ev, GameEvent.PADDLE));
        assertEquals(GameStatus.PLAYING, s.status);
    }

    @Test
    void rightPaddleReturnsBall() {
        s.paddle2Y = 250;
        s.ballX = WIDTH - PADDLE_MARGIN - PADDLE_WIDTH - BALL_RADIUS - 1;
        s.ballY = 250;
        s.ballVx = 400;
        engine.update(s, in1, in2, DT);
        assertTrue(s.ballVx < 0);
    }

    @Test
    void hittingPaddleEdgeChangesAngle() {
        s.paddle1Y = 250;
        s.ballX = PADDLE_MARGIN + PADDLE_WIDTH + BALL_RADIUS + 1;
        s.ballY = 250 + PADDLE_HEIGHT / 2 - 5; // near the lower edge
        s.ballVx = -400;
        engine.update(s, in1, in2, DT);
        assertTrue(s.ballVy > 100, "edge hits should deflect the ball strongly downward");
    }

    @Test
    void ballSpeedIsCapped() {
        s.paddle1Y = 250;
        s.ballX = PADDLE_MARGIN + PADDLE_WIDTH + BALL_RADIUS + 1;
        s.ballY = 250;
        s.ballVx = -MAX_BALL_SPEED;
        engine.update(s, in1, in2, DT);
        assertTrue(Math.hypot(s.ballVx, s.ballVy) <= MAX_BALL_SPEED + 0.001);
    }

    @Test
    void missedBallScoresForOpponentAndReturnsToCenter() {
        s.paddle1Y = 60; // far from the ball
        s.ballX = -BALL_RADIUS - 1;
        s.ballY = 400;
        s.ballVx = -400;
        List<GameEvent> ev = engine.update(s, in1, in2, DT);
        assertEquals(1, s.score2);
        assertEquals(0, s.score1);
        assertTrue(has(ev, GameEvent.SCORE));
        assertEquals(WIDTH / 2, s.ballX, 0.001);
        assertEquals(HEIGHT / 2, s.ballY, 0.001);
        assertEquals(GameStatus.COUNTDOWN, s.status);
        assertTrue(s.ballVx < 0, "serve goes towards the player who just conceded (player 1, on the left)");
    }

    @Test
    void rightSideMissScoresForPlayerOne() {
        s.paddle2Y = 60;
        s.ballX = WIDTH + BALL_RADIUS + 1;
        s.ballY = 400;
        s.ballVx = 400;
        engine.update(s, in1, in2, DT);
        assertEquals(1, s.score1);
    }

    @Test
    void matchEndsAtTargetScore() {
        s.targetScore = 5;
        s.score2 = 4;
        s.paddle1Y = 60;
        s.ballX = -BALL_RADIUS - 1;
        s.ballY = 400;
        s.ballVx = -400;
        List<GameEvent> ev = engine.update(s, in1, in2, DT);
        assertEquals(GameStatus.GAME_OVER, s.status);
        assertEquals(2, s.winner);
        assertEquals(5, s.score2);
        assertTrue(has(ev, GameEvent.WIN));
    }

    @Test
    void countdownThenPlaying() {
        engine.startMatch(s);
        assertEquals(GameStatus.COUNTDOWN, s.status);
        double bx = s.ballX;
        for (int i = 0; i < 120; i++) engine.update(s, in1, in2, DT);
        assertEquals(GameStatus.COUNTDOWN, s.status, "still counting after 2 s");
        assertEquals(bx, s.ballX, 0.0001, "ball must not move during the countdown");
        for (int i = 0; i < 70; i++) engine.update(s, in1, in2, DT);
        assertEquals(GameStatus.PLAYING, s.status);
    }

    @Test
    void pausedGameDoesNotMoveAndResumesWithCountdown() {
        s.ballVx = 300;
        engine.pause(s, 1);
        double x = s.ballX;
        engine.update(s, in1, in2, 0.05);
        assertEquals(x, s.ballX, 0.0001);
        engine.resume(s);
        assertEquals(GameStatus.COUNTDOWN, s.status);
    }

    @Test
    void paddleMovesAtLimitedSpeedAndStaysInsideArena() {
        s.paddle1Y = 250;
        in1.setDirection(-1);
        engine.update(s, in1, in2, 0.1);
        assertEquals(250 - PADDLE_SPEED * 0.1, s.paddle1Y, 0.01);
        for (int i = 0; i < 200; i++) engine.update(s, in1, in2, DT);
        assertEquals(PADDLE_HEIGHT / 2, s.paddle1Y, 0.001);
    }

    @Test
    void targetInputCannotTeleportPaddle() {
        s.paddle2Y = 100;
        in2.setTarget(450);
        engine.update(s, in1, in2, DT);
        assertTrue(s.paddle2Y - 100 <= TARGET_FOLLOW_SPEED * DT + 0.001, "paddle chases, it does not jump");
        assertTrue(s.paddle2Y > 100);
    }

    @Test
    void invalidPlayerInputIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> in1.setDirection(2));
        assertThrows(IllegalArgumentException.class, () -> in1.setTarget(Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> in1.setTarget(Double.POSITIVE_INFINITY));
    }

    @Test
    void longSimulationNeverLeavesArenaWithoutScoringOrGetsStuck() {
        engine.startMatch(s);
        s.targetScore = 1000;
        // Track the ball with both paddles so the rally keeps going.
        for (int i = 0; i < 60 * 60; i++) {
            in1.setTarget(s.ballY);
            in2.setTarget(s.ballY);
            engine.update(s, in1, in2, DT);
            assertTrue(s.ballY >= 0 && s.ballY <= HEIGHT, "ball Y out of bounds at step " + i);
            assertFalse(Double.isNaN(s.ballX));
            if (s.status == GameStatus.PLAYING) {
                assertTrue(Math.abs(s.ballVx) > 100, "ball must keep moving horizontally (never stuck)");
            }
        }
    }
}
