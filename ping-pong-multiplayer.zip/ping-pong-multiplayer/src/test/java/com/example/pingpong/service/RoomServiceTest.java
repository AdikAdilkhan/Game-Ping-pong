package com.example.pingpong.service;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pingpong.exception.ApiException;
import com.example.pingpong.service.RoomService.Joined;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class RoomServiceTest {
    private RoomService rooms;

    @BeforeEach
    void setUp() { rooms = new RoomService(); }

    @Test
    void createRoomGeneratesValidCodeAndHost() {
        Joined j = rooms.createRoom("Alice", false);
        assertTrue(RoomService.CODE.matcher(j.room().getCode()).matches());
        assertEquals(1, j.player().getSlot());
        assertTrue(j.player().isHost());
        assertTrue(rooms.find(j.room().getCode()).isPresent());
    }

    @Test
    void roomCodesAreUnique() {
        Set<String> codes = new HashSet<>();
        for (int i = 0; i < 300; i++) codes.add(rooms.createRoom("P", false).room().getCode());
        assertEquals(300, codes.size());
    }

    @Test
    void joinPutsGuestInSlotTwoCaseInsensitively() {
        Joined host = rooms.createRoom("Alice", false);
        Joined guest = rooms.joinRoom(host.room().getCode().toLowerCase(), "Bob");
        assertEquals(2, guest.player().getSlot());
        assertTrue(guest.room().isFull());
        assertNotEquals(host.player().getId(), guest.player().getId());
    }

    @Test
    void thirdPlayerIsRejectedWithRoomFull() {
        Joined host = rooms.createRoom("Alice", false);
        rooms.joinRoom(host.room().getCode(), "Bob");
        ApiException e = assertThrows(ApiException.class, () -> rooms.joinRoom(host.room().getCode(), "Eve"));
        assertEquals("ROOM_FULL", e.getCode());
        assertEquals(HttpStatus.CONFLICT, e.getStatus());
    }

    @Test
    void unknownRoomGives404() {
        ApiException e = assertThrows(ApiException.class, () -> rooms.joinRoom("ZZZZZZ", "Bob"));
        assertEquals("ROOM_NOT_FOUND", e.getCode());
        assertEquals(HttpStatus.NOT_FOUND, e.getStatus());
    }

    @Test
    void malformedCodesAndNicknamesAreRejected() {
        assertEquals("INVALID_CODE", assertThrows(ApiException.class, () -> rooms.joinRoom("abc", "Bob")).getCode());
        assertEquals("INVALID_CODE", assertThrows(ApiException.class, () -> rooms.joinRoom("A7K9O0", "Bob")).getCode());
        assertEquals("INVALID_NICKNAME", assertThrows(ApiException.class, () -> rooms.createRoom("  ", false)).getCode());
        assertEquals("INVALID_NICKNAME", assertThrows(ApiException.class, () -> rooms.createRoom("<script>", false)).getCode());
        assertEquals("INVALID_NICKNAME", assertThrows(ApiException.class, () -> rooms.createRoom("x".repeat(17), false)).getCode());
        assertEquals("INVALID_NICKNAME", assertThrows(ApiException.class, () -> rooms.createRoom(null, false)).getCode());
    }

    @Test
    void removedRoomCannotBeJoined() {
        Joined host = rooms.createRoom("Alice", false);
        rooms.remove(host.room().getCode());
        assertThrows(ApiException.class, () -> rooms.joinRoom(host.room().getCode(), "Bob"));
    }

    @Test
    void quickPlayPairsTwoPlayersInOnePublicRoom() {
        Joined first = rooms.quickPlay("Alice");
        first.player().setConnected(true); // the host has opened their socket
        Joined second = rooms.quickPlay("Bob");
        assertEquals(first.room().getCode(), second.room().getCode());
        assertEquals(2, second.player().getSlot());
        Joined third = rooms.quickPlay("Cara");
        assertNotEquals(first.room().getCode(), third.room().getCode());
    }
}
