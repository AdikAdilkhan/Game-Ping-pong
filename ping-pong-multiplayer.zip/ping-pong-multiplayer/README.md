# NEON PONG – real-time LAN multiplayer Ping Pong

Spring Boot 3 + native WebSocket (server-authoritative physics) + HTML5 Canvas.
Two players on two devices in the same Wi-Fi play against each other; no cloud, no external services.

## 1. Install Java and Maven
* **Java 17+** (JDK): https://adoptium.net  – check with `java -version`
* **Maven 3.8+**: https://maven.apache.org/download.cgi – check with `mvn -version`
  * Windows: `winget install EclipseAdoptium.Temurin.17.JDK Apache.Maven`
  * macOS: `brew install openjdk@17 maven`
  * Ubuntu/Debian: `sudo apt install openjdk-17-jdk maven`

## 2. Open and start the server
```bash
cd ping-pong-multiplayer
mvn spring-boot:run            # or: mvn package && java -jar target/ping-pong-multiplayer-1.0.0.jar
# other port:  PORT=9090 mvn spring-boot:run      (Windows PowerShell: $env:PORT=9090; mvn spring-boot:run)
```
(Open the folder in IntelliJ/Eclipse/VS Code as a Maven project and run `GameApplication` if you prefer an IDE.)
The console prints the addresses, e.g. `Other devices : http://<your-ip>:8080`. The server binds to `0.0.0.0`.

## 3. Find the computer's Wi-Fi IPv4 address (if the banner shows none)
* Windows: `ipconfig` → "Wireless LAN adapter Wi-Fi" → *IPv4 Address*
* macOS: `ipconfig getifaddr en0`
* Linux: `hostname -I` or `ip -4 addr`

## 4. Allow the server through the firewall
* Windows (admin PowerShell): `netsh advfirewall firewall add rule name="Neon Pong" dir=in action=allow protocol=TCP localport=8080`
  (or accept the "Allow access" prompt for Java on **Private** networks)
* macOS: System Settings → Network → Firewall → allow incoming connections for Java
* Linux (ufw): `sudo ufw allow 8080/tcp`

## 5. Play
1. Both devices join the **same Wi-Fi** (guest/public Wi-Fi with "client isolation" blocks this – use a normal network or a phone hotspot).
2. Host opens `http://localhost:8080`, enters a nickname, **CREATE ROOM**. Room code + LAN URL are shown.
3. Second device opens that LAN URL (never `localhost`), nickname + room code → **JOIN ROOM**.
   (**PLAY ONLINE** auto-pairs two people who both press it.)
4. Lobby: guest presses **I'M READY**, host picks target score (5/7/10) and presses **START MATCH**.
5. Controls: host = left paddle, guest = right paddle. `W`/`S` or `↑`/`↓`, mouse, or drag a finger on the arena. `P`/`Esc` pauses.
   Each device only steers its own paddle (decided by the server from the connection, not by the message).
   Phones: landscape gives the biggest arena.

## Architecture
| Part | Role |
|---|---|
| `RoomController` | REST: `POST /api/rooms`, `/api/rooms/quick`, `/api/rooms/{code}/join`, `GET /api/rooms/{code}`, `/api/network` |
| `GameWebSocketController` | `/ws` transport, JSON parsing, flood limit |
| `GameService` | session binding, validation, 60 Hz scheduled loop, 30 Hz broadcast, reconnection (30 s grace), pause on disconnect |
| `GameEngine` | pure physics: sub-stepped ball, wall/paddle collisions, speed-up, scoring, countdown |
| `RoomService` | thread-safe rooms, 6-char codes (no 0/O/1/I), capacity 2, validation |
| `NetworkUtils` | LAN IPv4 detection |
Clients only render; ball and score come from the server and are smoothed by extrapolation/easing.
Settings: `src/main/resources/application.properties` (port, tick rate, broadcast divisor, grace period).

## WebSocket protocol (JSON)
Client→server: `join{code,playerId}`, `input{dir:-1|0|1}` or `input{y}`, `ready`, `settings{targetScore}`, `start`, `pause`, `resume`, `restart`, `rematch`, `leave`, `ping`.
Server→client: `welcome`, `room` (lobby/players/status), `state` (`st,cd,b[x,y,vx,vy],p[p1,p2],sc,ev`), `notice`, `error`, `closed`, `pong`.

## Tests
`mvn test` runs engine tests (movement, walls, paddles, scoring, match end, input validation), room tests (create/join/capacity/codes),
game-service tests (permissions, disconnect/reconnect, duplicate sessions, grace expiry, rematch) and `MultiplayerFlowTest`,
which starts the real server and connects two real WebSocket clients (create → join → ready → start → play → state sync).

## Troubleshooting
* Second device can't load the page: wrong Wi-Fi, firewall (step 4), or AP client isolation.
* "Room not found": the code is case-insensitive but must be exact; rooms are removed when the host leaves or never connects within 30 s.
* No sound: tap the page once (browsers block audio until a gesture) and check the Sound toggle.
